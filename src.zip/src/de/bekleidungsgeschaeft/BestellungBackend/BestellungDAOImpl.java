package de.bekleidungsgeschaeft.BestellungBackend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import de.bekleidungsgeschaeft.besttellung.Bestellung;
import de.bekleidungsgeschaeft.produkte.Blazer;
import de.bekleidungsgeschaeft.produkte.Produkt;

public class BestellungDAOImpl  implements BestellungDAO{
	
	private List<Bestellung> alleBestellung = new ArrayList<Bestellung>();
	private String dbURL = "jdbc:mysql://localhost:3306/project_db";
	private String user = "root";
	private String pw = "";
	private int kassenBon;
	
	
	@Override
	public List<Bestellung> getAllBestellung(int idKassenBon) {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw); Statement stmt = conn.createStatement()) {
			String sql = "SELECT * FROM bestellung where id_kassenbon="+idKassenBon;
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {

				Bestellung eins =new Bestellung(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getInt(4), rs.getDouble(5), rs.getLong(6));

				alleBestellung.add(eins);
			}

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}

		return alleBestellung;
		
	
	}

	@Override
	public void addBestellung(Bestellung bestellung) {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw)) {
			String sql = "INSERT INTO  bestellung  VALUES (null,?,?,?,?,0)";
			PreparedStatement prepstmt = conn.prepareStatement(sql);
			prepstmt.setLong(1, bestellung.getId_produkttype());
			prepstmt.setString(2, bestellung.getProdukttype());
			prepstmt.setInt(3, bestellung.getId_kassenbonn());
			prepstmt.setDouble(4, bestellung.getPreise());
		//	prepstmt.setLong(4, bestellung.getId_kund());
			prepstmt.execute();

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}
		
	}

	@Override
	public void updateBestellung(Bestellung bestellung) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteBestellung(Bestellung bestellung) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Bestellung> getBestellungById(int idKassenBon) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getMaxIdKassenBon() {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw); Statement stmt = conn.createStatement()) {
			String sql = "SELECT MAX(id_kassenbon) FROM bestellung";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				kassenBon=rs.getInt(1);

			}
		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}
		return kassenBon;
	}

}
