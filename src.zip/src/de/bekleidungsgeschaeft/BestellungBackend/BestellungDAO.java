package de.bekleidungsgeschaeft.BestellungBackend;

import java.util.List;

import de.bekleidungsgeschaeft.besttellung.Bestellung;


public interface BestellungDAO {
	
	List<Bestellung> getAllBestellung(int idKassenBon);
	void addBestellung(Bestellung bestellung);
	void updateBestellung(Bestellung bestellung);
	void deleteBestellung(Bestellung bestellung);

	List<Bestellung> getBestellungById(int idKassenBon);
	int getMaxIdKassenBon();
	

}
