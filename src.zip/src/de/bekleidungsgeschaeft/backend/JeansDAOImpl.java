package de.bekleidungsgeschaeft.backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import de.bekleidungsgeschaeft.produkte.Bluse;
import de.bekleidungsgeschaeft.produkte.Jeans;
import de.bekleidungsgeschaeft.produkte.Produkt;

public class JeansDAOImpl implements ProduktDAO {

	private List<Produkt> alleProdukte = new ArrayList<Produkt>();
	private String dbURL = "jdbc:mysql://localhost:3306/project_db";
	private String user = "root";
	private String pw = "";
	private Produkt neuJeans;

	@Override
	public List<Produkt> getAllprodukt() {
		try ( Connection conn =DriverManager.getConnection(dbURL,user,pw);
				Statement stmt = conn.createStatement()){
				String sql = "SELECT id_jeans,jeans.id_produkt,farbe,gro�e,mange,image_ein,image_zwei,image_drei,image_vier,p.preise,p.produkt_type FROM jeans ,produkt p\r\n "+
						"WHERE p.produkt_type='Jeans' GROUP by farbe,id_produkt";
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next()) {
					
					String[] image=new String[4];
					image[0]=rs.getString(6);
					image[1]=rs.getString(7);
					image[2]=rs.getString(8);
					image[3]=rs.getString(9);
					Jeans st�ck=new Jeans(rs.getLong(1),rs.getLong(2),rs.getString(3),rs.getInt(4),rs.getInt(5),image,rs.getDouble(10),rs.getString(11));
			
			 	alleProdukte.add(st�ck);
				}
				
			}catch(SQLException sqlAusnahme) {
				sqlAusnahme.printStackTrace();
			}

			return alleProdukte;
		
	}

	@Override
	public void addprodukt(Produkt kleidung) {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw)) {
			String sql = "INSERT INTO  jeans  VALUES (null,?,?,?,?,?,?,?,?)";
			PreparedStatement prepstmt =conn.prepareStatement(sql);
			Jeans produktType=(Jeans)kleidung;
			prepstmt.setLong(1, produktType.getId_produkt());
			prepstmt.setString(2, produktType.getFarbe());
			prepstmt.setInt(3, produktType.getGro�e());
			prepstmt.setInt(4, produktType.getMange());
			prepstmt.setString(5, produktType.getImage()[0]);
			prepstmt.setString(6, produktType.getImage()[1]);
			prepstmt.setString(7, produktType.getImage()[2]);
			prepstmt.setString(8, produktType.getImage()[3]);
			prepstmt.execute();

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}
		
	}

	@Override
	public void updateProdukt(Long id,String aendern) {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw)) {
			String sql = "UPDATE jeans SET mange = mange-1 WHERE id_jeans=" + id;
			String sqlA = "UPDATE jeans SET mange = mange+1 WHERE id_jeans=" + id;
			if (aendern == "-") {
				PreparedStatement prepstmt = conn.prepareStatement(sql);
				prepstmt.execute();
			}else{
				PreparedStatement prepstmt = conn.prepareStatement(sqlA);
				prepstmt.execute();
			}
		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}
		
	}

	@Override
	public void deleteProdukt(Produkt pkleidunget) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Produkt getPorduktById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
	public Produkt getPorduktByArtikelNr(String artikelNr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Produkt getAllMange(Long id, String farbe, int gro�e) {
		try ( Connection conn =DriverManager.getConnection(dbURL,user,pw);
				Statement stmt = conn.createStatement()){
		
		String sql="SELECT id_jeans,mange FROM jeans WHERE  id_produkt=" + id + " AND gro�e=" + gro�e + " AND farbe=\"" 
				+farbe +"\"";

		
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()) {
		neuJeans=new Jeans(rs.getLong(1),rs.getInt(2));
		}
		
		}catch(SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}
		return neuJeans;
	}

}
