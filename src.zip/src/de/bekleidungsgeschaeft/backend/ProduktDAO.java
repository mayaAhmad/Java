package de.bekleidungsgeschaeft.backend;

import java.util.List;

import de.bekleidungsgeschaeft.produkte.Produkt;



public interface ProduktDAO {
	List<Produkt> getAllprodukt();
	void addprodukt(Produkt kleidung);
	void updateProdukt(Long id, String aendern);
	void deleteProdukt(Produkt pkleidunget);

	Produkt getPorduktById(Long id);
	Produkt getPorduktByArtikelNr(String artikelNr);
	Produkt  getAllMange(Long id,String farbe,int gro�e);

}
