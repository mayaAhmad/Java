package de.bekleidungsgeschaeft.backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import de.bekleidungsgeschaeft.produkte.Blazer;
import de.bekleidungsgeschaeft.produkte.Produkt;

public class BlazerDAOImpl implements ProduktDAO {

	private List<Produkt> alleProdukte = new ArrayList<Produkt>();
	private String dbURL = "jdbc:mysql://localhost:3306/project_db";
	private String user = "root";
	private String pw = "";
	Blazer neu;

	@Override
	public List<Produkt> getAllprodukt() {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw); Statement stmt = conn.createStatement()) {
			String sql = "SELECT id_blazer,blazer.id_produkt,farbe,gro�e,mange,image_ein,image_zwei,image_drei,image_vier,p.preise,p.produkt_type FROM blazer ,produkt p\r\n"
					+ "WHERE p.produkt_type='Blazer' GROUP by farbe,id_produkt";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {

				String[] image = new String[4];
				image[0] = rs.getString(6);
				image[1] = rs.getString(7);
				image[2] = rs.getString(8);
				image[3] = rs.getString(9);
				Blazer st�ck = new Blazer(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getInt(4), rs.getInt(5),
						image, rs.getDouble(10), rs.getString(11));

				alleProdukte.add(st�ck);
			}

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}

		return alleProdukte;

	}

	@Override
	public void addprodukt(Produkt kleidung) {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw)) {
			String sql = "INSERT INTO  blazer  VALUES (null,?,?,?,?,?,?,?,?)";
			PreparedStatement prepstmt = conn.prepareStatement(sql);
			Blazer blazer = (Blazer) kleidung;
			prepstmt.setLong(1, blazer.getId_produkt());
			prepstmt.setString(2, blazer.getFarbe());
			prepstmt.setInt(3, blazer.getGro�e());
			prepstmt.setInt(4, blazer.getMange());
			prepstmt.setString(5, blazer.getImage()[0]);
			prepstmt.setString(6, blazer.getImage()[1]);
			prepstmt.setString(7, blazer.getImage()[2]);
			prepstmt.setString(8, blazer.getImage()[3]);
			prepstmt.execute();

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}

	}

	@Override
	public void updateProdukt(Long id, String aendern) {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw)) {
			String sql = "UPDATE blazer SET mange = mange-1 WHERE id_blazer=" + id;
			String sqlA = "UPDATE blazer SET mange = mange+1 WHERE id_blazer=" + id;
			if (aendern == "-") {
				PreparedStatement prepstmt = conn.prepareStatement(sql);
				prepstmt.execute();
			}else{
				PreparedStatement prepstmt = conn.prepareStatement(sqlA);
				prepstmt.execute();
			}

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}

	}

	@Override
	public void deleteProdukt(Produkt pkleidunget) {
		// TODO Auto-generated method stub

	}

	@Override
	public Produkt getPorduktByArtikelNr(String artikelNr) {
		// TODO Auto-generated method stub
		return null;
	}

	public Produkt getPorduktById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Produkt getAllMange(Long id, String farbe, int gro�e) {

		try (Connection conn = DriverManager.getConnection(dbURL, user, pw); Statement stmt = conn.createStatement()) {

			String sql = "SELECT id_blazer,mange FROM blazer  WHERE  id_produkt=" + id + " AND gro�e=" + gro�e
					+ " AND farbe=\"" + farbe + "\"";

			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				neu = new Blazer(rs.getLong(1), rs.getInt(2));
			}
		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}
		return neu;

	}

}
