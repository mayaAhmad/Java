package de.bekleidungsgeschaeft.backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import de.bekleidungsgeschaeft.produkte.Produkt;

public class ProduktDAOImpl implements ProduktDAO {

	private List<Produkt> alleProdukte = new ArrayList<Produkt>();
	private Produkt produkt=new Produkt();
	private String dbURL = "jdbc:mysql://localhost:3306/project_db";
	private String user = "root";
	private String pw = "";

	@Override
	public List<Produkt> getAllprodukt() {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw); Statement stmt = conn.createStatement()) {
			String sql = "SELECT * FROM produkt";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Produkt produktSt�ck = new Produkt(rs.getLong("id_produkt"), rs.getString("produktDetails"),
						rs.getString("material"), rs.getString("pflage"), rs.getString("artikel_nr"), rs.getDouble(6),
						rs.getString("produkt_type"));

				alleProdukte.add(produktSt�ck);

			}

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}

		return alleProdukte;
	}

	@Override
	public void addprodukt(Produkt kleidung) {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw)) {
			String sql = "INSERT INTO  produkt  VALUES (null,?,?,?,?,?,?)";
			PreparedStatement prepstmt =conn.prepareStatement(sql);
			
			prepstmt.setString(1, kleidung.getProduktDetails());
			prepstmt.setString(2, kleidung.getMaterial());
			prepstmt.setString(3, kleidung.getPflege());
			prepstmt.setString(4, kleidung.getArtikelNr());
			prepstmt.setDouble(5, kleidung.getPreise());
			prepstmt.setString(6, kleidung.getProduktType());
			prepstmt.execute();

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}
	}

	@Override
	public void updateProdukt(Long id,String aendern) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteProdukt(Produkt pkleidunget) {
		// TODO Auto-generated method stub

	}

	@Override
	public Produkt getPorduktByArtikelNr(String artikelNr){
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw); Statement stmt = conn.createStatement()) {
			String sql = "SELECT * FROM produkt WHERE artikel_nr="+artikelNr;
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				 produkt = new Produkt(rs.getLong("id_produkt"), rs.getString("produktDetails"),
						rs.getString("material"), rs.getString("pflage"), rs.getString("artikel_nr"), rs.getDouble(6),
						rs.getString("produkt_type"));

				

			}

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}

		return produkt;
		
		
	}
	public Produkt getPorduktById(Long id) {
		try (Connection conn = DriverManager.getConnection(dbURL, user, pw); Statement stmt = conn.createStatement()) {
			String sql = "SELECT * FROM produkt WHERE id_produkt="+id;
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				 produkt = new Produkt(rs.getLong("id_produkt"), rs.getString("produktDetails"),
						rs.getString("material"), rs.getString("pflage"), rs.getString("artikel_nr"), rs.getDouble(6),
						rs.getString("produkt_type"));

				

			}

		} catch (SQLException sqlAusnahme) {
			sqlAusnahme.printStackTrace();
		}

		return produkt;
	}

	@Override
	public Produkt getAllMange(Long id, String farbe, int gro�e) {
		// TODO Auto-generated method stub
		return null;
	}
	


}
