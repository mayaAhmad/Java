package de.bekleidungsgeschaeft.kunden;

public class Adresse {
	protected Long id_adresse;
	protected Long id_kunde;
	private String ort;
	private String stra�e;
	private int postzahl;
	private String hauseNummer;

	public Adresse() {

	}

	public Adresse(Long id_adresse, Long id_kunde, String ort, String stra�e, int postzahl, String hauseNummer) {
		this.id_adresse = id_adresse;
		this.id_kunde = id_kunde;
		this.ort = ort;
		this.stra�e = stra�e;
		this.postzahl = postzahl;
		this.hauseNummer = hauseNummer;
	}

	public Adresse(Long id_kunde, String ort, String stra�e, int postzahl, String hauseNummer) {
		this.id_kunde = id_kunde;
		this.ort = ort;
		this.stra�e = stra�e;
		this.postzahl = postzahl;
		this.hauseNummer = hauseNummer;
	}

	public String getOrt() {
		return ort;
	}

	public String getStra�e() {
		return stra�e;
	}

	public int getPostzahl() {
		return postzahl;
	}

	public String getHauseNummer() {
		return hauseNummer;
	}

	@Override
	public String toString() {
		return "Adresse [ort=" + ort + ", stra�e=" + stra�e + ", postzahl=" + postzahl + ", hauseNummer=" + hauseNummer
				+ "]";
	}

}
