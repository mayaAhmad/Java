package de.bekleidungsgeschaeft.kunden;

import java.time.LocalDate;



public class Kunde {
	protected Long id_kunde;
	private String vorName;
	private String nachName;
	private LocalDate geborstag;
	private long telefeonNummer;
	private String email;
	private Adresse adresse;
	protected int clubPoint;
	
	
	
	public Kunde() {
	}



	public Kunde(Long id_kunde, String vorName, String nachName, LocalDate geborstag, long telefeonNummer, String email,
			Adresse adresse, int clubPoint) {
		this.id_kunde = id_kunde;
		this.vorName = vorName;
		this.nachName = nachName;
		this.geborstag = geborstag;
		this.telefeonNummer = telefeonNummer;
		this.email = email;
		this.adresse = adresse;
		this.clubPoint = clubPoint;
	}



	public Kunde(String vorName, String nachName, LocalDate geborstag, long telefeonNummer, String email,
			Adresse adresse, int clubPoint) {
		this.vorName = vorName;
		this.nachName = nachName;
		this.geborstag = geborstag;
		this.telefeonNummer = telefeonNummer;
		this.email = email;
		this.adresse = adresse;
		this.clubPoint = clubPoint;
	}



	public String getVorName() {
		return vorName;
	}



	public void setVorName(String vorName) {
		this.vorName = vorName;
	}



	public String getNachName() {
		return nachName;
	}



	public void setNachName(String nachName) {
		this.nachName = nachName;
	}



	public LocalDate getGeborstag() {
		return geborstag;
	}



	public void setGeborstag(LocalDate geborstag) {
		this.geborstag = geborstag;
	}



	public long getTelefeonNummer() {
		return telefeonNummer;
	}



	public void setTelefeonNummer(long telefeonNummer) {
		this.telefeonNummer = telefeonNummer;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public Adresse getAdresse() {
		return adresse;
	}



	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}



	public int getClubPoint() {
		return clubPoint;
	}



	public void setClubPoint(int clubPoint) {
		this.clubPoint = clubPoint;
	}



	public Long getId_kunde() {
		return id_kunde;
	}



	@Override
	public String toString() {
		return "Kunde [id_kunde=" + id_kunde + ", vorName=" + vorName + ", nachName=" + nachName + ", geborstag="
				+ geborstag + ", telefeonNummer=" + telefeonNummer + ", email=" + email + ", adresse=" + adresse
				+ ", clubPoint=" + clubPoint + "]";
	}
	


}
