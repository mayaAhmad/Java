package de.bekleidungsgeschaeft.besttellung;

public class Bestellung {
	private Long id_bestellung;
	private Long id_produkttype;
	private String produkttype;
	private int id_kassenbonn;
	private double preise;
	private Long id_kund;
	
	
	public Bestellung() {
		
	}
	
	public Bestellung(Long id_produkttype, String produkttype,int id_kassenbonn, double preise, Long id_kund) {
		this.id_produkttype = id_produkttype;
		this.produkttype=produkttype;
		this.id_kassenbonn = id_kassenbonn;
		this.preise = preise;
		this.id_kund = id_kund;
	}

	
	


	public Bestellung(Long id_bestellung, Long id_produkttype,String produkttype, int id_kassenbonn, double preise, Long id_kund) {
		this.id_bestellung = id_bestellung;
		this.id_produkttype = id_produkttype;
		this.produkttype=produkttype;
		this.id_kassenbonn = id_kassenbonn;
		this.preise = preise;
		this.id_kund = id_kund;
	}
	public Bestellung( Long id_produkttype,String produkttype, int id_kassenbonn, double preise) {
		this.id_produkttype = id_produkttype;
		this.produkttype=produkttype;
		this.id_kassenbonn = id_kassenbonn;
		this.preise = preise;
	
	}
	
	public Long getId_produkttype() {
		return id_produkttype;
	}

	public String getProdukttype() {
		return produkttype;
	}

	public void setProdukttype(String produkttype) {
		this.produkttype = produkttype;
	}

	public void setId_produkttype(Long id_produkttype) {
		this.id_produkttype = id_produkttype;
	}

	public int getId_kassenbonn() {
		return id_kassenbonn;
	}

	public void setId_kassenbonn(int id_kassenbonn) {
		this.id_kassenbonn = id_kassenbonn;
	}

	public double getPreise() {
		return preise;
	}

	public void setPreise(double preise) {
		this.preise = preise;
	}

	public Long getId_kund() {
		return id_kund;
	}

	public void setId_kund(Long id_kund) {
		this.id_kund = id_kund;
	}

	@Override
	public String toString() {
		return "Bestellung [id_bestellung=" + id_bestellung + ", id_produkttype=" + id_produkttype + ", produkttype="
				+ produkttype + ", id_kassenbonn=" + id_kassenbonn + ", preise=" + preise + ", id_kund=" + id_kund
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id_produkttype == null) ? 0 : id_produkttype.hashCode());
		long temp;
		temp = Double.doubleToLongBits(preise);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((produkttype == null) ? 0 : produkttype.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Bestellung)) {
			return false;
		}
		Bestellung other = (Bestellung) obj;
		if (id_produkttype == null) {
			if (other.id_produkttype != null) {
				return false;
			}
		} else if (!id_produkttype.equals(other.id_produkttype)) {
			return false;
		}
		if (Double.doubleToLongBits(preise) != Double.doubleToLongBits(other.preise)) {
			return false;
		}
		if (produkttype == null) {
			if (other.produkttype != null) {
				return false;
			}
		} else if (!produkttype.equals(other.produkttype)) {
			return false;
		}
		return true;
	}






	

}
