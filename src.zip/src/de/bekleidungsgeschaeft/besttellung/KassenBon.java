package de.bekleidungsgeschaeft.besttellung;

import java.util.List;

public class KassenBon {
	private static int id=1;
	private List<Bestellung> bestellungs;
	private double total;
	
	public KassenBon(List<Bestellung> bestellung) {
		
		
		this.bestellungs=bestellung;
		id++;
		
	}
	public double totalPreise() {
		bestellungs.forEach(stuck->{
			total+=stuck.getPreise();
		});
		
		return total;
	}
	public List<Bestellung> getBestellungs() {
		return bestellungs;
	}
	public void setBestellungs(List<Bestellung> bestellungs) {
		this.bestellungs = bestellungs;
	}
	public double getTotal() {
		return total;
	}
	public static int getId() {
		return id;
	}
	public static void setId(int id) {
		KassenBon.id = id;
	}
	@Override
	public String toString() {
		return "KassenBon [bestellungs=" + bestellungs + ", total=" + total + "]";
	}

}
