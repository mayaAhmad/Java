package de.bekleidungsgeschaeft.fronted;

import java.util.List;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import de.bekleidungsgeschaeft.backend.*;
import de.bekleidungsgeschaeft.middel.ProduktService;
import de.bekleidungsgeschaeft.produkte.*;

/**
 * AlleProdukteAPI Klasse ist Vererbung von JTabbedPane Klasse jeder Prdukt type
 * wird in verchiden tab sortiert ,um besser Prdoukt zu sehen alle Prdoukt wird
 * in DataBase gekommt
 * 
 * @author maya
 *
 */
@SuppressWarnings("serial")
public class AlleProdukteAPI extends JTabbedPane {

//	private InnerAlleProdukte alleprodukte = new InnerAlleProdukte();
	private InnerAlleBlazer alleblazer = new InnerAlleBlazer();
	private InnerAlleBlusen alleblusen = new InnerAlleBlusen();
	private InnerAlleHosen allehosen = new InnerAlleHosen();
	private InnerAlleJacken allejacken = new InnerAlleJacken();
	private InnerAlleJeans alljeans = new InnerAlleJeans();
	private InnerAlleKleider allKleider = new InnerAlleKleider();
	private InnerAllePullover allpullover = new InnerAllePullover();
	private InnerAlleRoeck allroeck = new InnerAlleRoeck();
	private InnerAlleShirts allshirt = new InnerAlleShirts();

	/**
	 * default Constructors :es wird verschiden Methode angeruft
	 */
	public AlleProdukteAPI() {
		zusammenBauen();

	}

	/**
	 * All Component in dieses Klasse wird hier gestellt
	 */
	private void zusammenBauen() {
		// this.add(alleprodukte, "Alle Produkte");
		this.add(alleblazer, "Alle Blazer");
		this.add(alleblusen, "Alle Blusen");
		this.add(allehosen, "Alle Hosen");
		this.add(allejacken, "Alle Jacken");
		this.add(alljeans, "Alle Jeans");
		this.add(allKleider, "Alle Kleider");
		this.add(allpullover, "Alle Pullover");
		this.add(allroeck, "Alle R�ck");
		this.add(allshirt, "Alle Shirts");

	}

	/**
	 * InnerAlleProdukte Klasse ist Vererbung von JPanel es wird alle Produkt in ein
	 * tab gestellt
	 * 
	 * @author Alfa
	 *
	 */
	class InnerAlleProdukte extends JPanel {
		private InnerAlleBlazer blazer = new InnerAlleBlazer();
		private InnerAlleBlusen blusen = new InnerAlleBlusen();
		private InnerAlleHosen hosen = new InnerAlleHosen();

		public InnerAlleProdukte() {

			this.add(blazer);
			this.add(hosen);
			this.add(blusen);

		}

	}

	/**
	 * InnerAlleBlazer Klasse ist Vererbung von JPanel wird es All Blazer
	 * gestellt,das bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */

	class InnerAlleBlazer extends JPanel {

		private ProduktDAO qulleBlazer = new BlazerDAOImpl();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qulleBlazer);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAlleBlazer() {

			datenbankZugriffAlleBlazer();
		}

		/**
		 * datenbankZugriffAlleBlazer ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffAlleBlazer() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Blazer convertToBlazer = (Blazer) e;
				neuPordukt.einProduktStellen(convertToBlazer.getId_produkt(), convertToBlazer.getFarbe(),
						convertToBlazer.getImage()[0], convertToBlazer.getProduktType(), convertToBlazer.getPreise());
				this.add(neuPordukt);
			});

		}

	}

	/**
	 * InnerAlleBlusen Klasse ist Vererbung von JPanel wird es All Blusen
	 * gestellt,das bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */
	class InnerAlleBlusen extends JPanel {

		private ProduktDAO qulleBluse = new BluseDAOImpl();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qulleBluse);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAlleBlusen() {
			datenbankZugriffAlleBluse();

		}

		/**
		 * datenbankZugriffAlleBluse ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffAlleBluse() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Bluse convertToBluse = (Bluse) e;
				neuPordukt.einProduktStellen(convertToBluse.getId_produkt(), convertToBluse.getFarbe(),
						convertToBluse.getImage()[0], convertToBluse.getProduktType(), convertToBluse.getPreise());
				this.add(neuPordukt);
			});

		}

	}

	/**
	 * InnerAlleHosen Klasse ist Vererbung von JPanel wird es All Hosen gestellt,das
	 * bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */
	class InnerAlleHosen extends JPanel {
		private ProduktDAO qulleHose = new HoseDAOImpl();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qulleHose);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAlleHosen() {
			datenbankZugriffAlleHosen();

		}

		/**
		 * datenbankZugriffAlleHosen ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffAlleHosen() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Hose convertToHose = (Hose) e;
				neuPordukt.einProduktStellen(convertToHose.getId_produkt(), convertToHose.getFarbe(),
						convertToHose.getImage()[0], convertToHose.getProduktType(), convertToHose.getPreise());
				this.add(neuPordukt);

			});

		}

	}

	/**
	 * InnerAlleJacken Klasse ist Vererbung von JPanel wird es All Jacken
	 * gestellt,das bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */
	class InnerAlleJacken extends JPanel {
		private ProduktDAO qulleJacke = new JackeDAOImpl();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qulleJacke);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAlleJacken() {
			datenbankZugriffAlleJacken();

		}

		/**
		 * datenbankZugriffAlleJacken ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffAlleJacken() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Jacke convertToJacke = (Jacke) e;
				neuPordukt.einProduktStellen(convertToJacke.getId_produkt(), convertToJacke.getFarbe(),
						convertToJacke.getImage()[0], convertToJacke.getProduktType(), convertToJacke.getPreise());
				this.add(neuPordukt);
			});

		}

	}

	/**
	 * InnerAlleJeans Klasse ist Vererbung von JPanel wird es All Jeans gestellt,das
	 * bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */
	class InnerAlleJeans extends JPanel {

		private ProduktDAO qulleJeans = new JeansDAOImpl();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qulleJeans);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAlleJeans() {
			datenbankZugriffAlleJeans();
		}

		/**
		 * datenbankZugriffAlleJeans ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffAlleJeans() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Jeans convertToJeans = (Jeans) e;
				neuPordukt.einProduktStellen(convertToJeans.getId_produkt(), convertToJeans.getFarbe(),
						convertToJeans.getImage()[0], convertToJeans.getProduktType(), convertToJeans.getPreise());
				this.add(neuPordukt);
			});

		}

	}

	/**
	 * InnerAlleKleider Klasse ist Vererbung von JPanel wird es All Kleid
	 * gestellt,das bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */
	class InnerAlleKleider extends JPanel {

		private ProduktDAO qulleKleid = new KleidDAOImpl();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qulleKleid);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAlleKleider() {
			datenbankZugriffAlleKleider();
		}

		/**
		 * datenbankZugriffAlleKleider ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffAlleKleider() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Kleid convertToKleid = (Kleid) e;
				neuPordukt.einProduktStellen(convertToKleid.getId_produkt(), convertToKleid.getFarbe(),
						convertToKleid.getImage()[0], convertToKleid.getProduktType(), convertToKleid.getPreise());
				this.add(neuPordukt);
			});

		}

	}

	/**
	 * InnerAllePullover Klasse ist Vererbung von JPanel wird es All Pullover
	 * gestellt,das bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */
	class InnerAllePullover extends JPanel {
		private ProduktDAO qullePullover = new PulloverDAOImpl();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qullePullover);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAllePullover() {
			datenbankZugriffAllePullover();
		}

		/**
		 * datenbankZugriffAllePullover ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffAllePullover() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Pullover convertToPullover = (Pullover) e;
				neuPordukt.einProduktStellen(convertToPullover.getId_produkt(), convertToPullover.getFarbe(),
						convertToPullover.getImage()[0], convertToPullover.getProduktType(),
						convertToPullover.getPreise());
				this.add(neuPordukt);
			});

		}

	}

	/**
	 * InnerAlleRoeck Klasse ist Vererbung von JPanel wird es All R�ck gestellt,das
	 * bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */
	class InnerAlleRoeck extends JPanel {
		private ProduktDAO qulleRoeck = new RoeckDAOImpl();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qulleRoeck);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAlleRoeck() {
			datenbankZugriffAlleRoeck();
		}

		/**
		 * datenbankZugriffAlleRoeck ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffAlleRoeck() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Roeck convertToRoeck = (Roeck) e;
				neuPordukt.einProduktStellen(convertToRoeck.getId_produkt(), convertToRoeck.getFarbe(),
						convertToRoeck.getImage()[0], convertToRoeck.getProduktType(), convertToRoeck.getPreise());
				this.add(neuPordukt);
			});

		}

	}

	/**
	 * InnerAlleShirts Klasse ist Vererbung von JPanel wird es All Shirt
	 * gestellt,das bedeutet dieses Klasse mit Datan Base geanruft wird
	 * 
	 * @author maya
	 *
	 */
	class InnerAlleShirts extends JPanel {
		private ProduktDAO qulleShirt = new ShirtDAOImp();
		private List<Produkt> alle;
		private ProduktService service = new ProduktService(qulleShirt);

		/**
		 * default Constructors es wird verschiden Methode angeruft
		 */
		public InnerAlleShirts() {
			datenbankZugriffShirts();
		}

		/**
		 * datenbankZugriffShirts ist ein Mthode zum DatenBank zu griefen
		 */
		private void datenbankZugriffShirts() {
			alle = service.getAlleProdukt();
			datenInFrameStellen(alle);

		}

		/**
		 * methode wird all information in die Haupt Fenster gestellt
		 * 
		 * @param alle
		 */
		private void datenInFrameStellen(List<Produkt> alle) {
			alle.forEach(e -> {
				EinProdukt neuPordukt = new EinProdukt();
				Shirt convertToShirt = (Shirt) e;
				neuPordukt.einProduktStellen(convertToShirt.getId_produkt(), convertToShirt.getFarbe(),
						convertToShirt.getImage()[0], convertToShirt.getProduktType(), convertToShirt.getPreise());
				this.add(neuPordukt);
			});

		}

	}

}
