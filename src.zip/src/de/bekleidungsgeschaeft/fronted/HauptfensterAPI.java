package de.bekleidungsgeschaeft.fronted;

/**
 * Kalsse ist HauptfensterAPI ist Vererbung von JFrame und ist die Haupt Fenster in Programm
 * es wied verscheden Elemment in javax.swing.* 
 */

import java.awt.BorderLayout;
import javax.swing.*;
import de.bekleidungsgeschaeft.BestellungFronted.RightFenster;


@SuppressWarnings("serial")
public class HauptfensterAPI extends JFrame {

	private JMenuBar menueLeister = new JMenuBar();
	private JMenu produkt = new JMenu("Produkt");
	private JMenu kunden = new JMenu("Kunden");
	private JMenu gutschein = new JMenu("Gutchein");
	//LeftFenster
	private LeftHauptFensterAPI leftFenster=new LeftHauptFensterAPI();
	//RightFenster 
	private RightFenster rightFenster=RightFenster.getInstance();
	// alle Proudkte anlegen 
	private AlleProdukteAPI produktAPI=new AlleProdukteAPI();
	
	/**
	 * default Constructors
	 * es wird die Haupt Fenster zusammen gebaut
	 */
	public HauptfensterAPI() {
		setTitle("Fashion Shop");
		setContentPane(new JScrollBarDemo());
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		menueBauen();
		alleProdukteBauen();


	}

	/**
	 * All Elemment hier wird gebuat
	 */
	private void alleProdukteBauen() {
		this.add(produktAPI,BorderLayout.CENTER);
		this.add(leftFenster,BorderLayout.WEST);
		this.add(rightFenster,BorderLayout.EAST);
		
		
		
		
	}

/**
 * Alle MemueElement wird gebaut
 */
	private void menueBauen() {
		
		// Produkt-Menue zusammenstellen
//		produkt.add(allprodukte);
//		produkt.add(neuprodukt);
//		produkt.add(anderungprodukt);
//		produkt.add(exit);
//
//		// Kunden-Menue zusammenstellen
//		kunden.add(grid);
//		kunden.add(flow);
//		kunden.add(border);
//
//		// menueLeister zusammenstellen
		menueLeister.add(produkt);
		menueLeister.add(kunden);
		menueLeister.add(gutschein);

		// Setzen der Menuleiste
		this.setJMenuBar(menueLeister);

	}

}
