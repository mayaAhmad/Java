package de.bekleidungsgeschaeft.fronted;

import java.awt.*;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import de.bekleidungsgeschaeft.BestellungFronted.*;
import de.bekleidungsgeschaeft.BestellungFronted.RightFenster;

@SuppressWarnings("serial")
public class EinProdukt extends JPanel {

	private JPanel einprodukt = new JPanel();
	private JLabel labelImage = new JLabel();
	private JLabel labeltypeprodukt = new JLabel();
	private JLabel labelpreis = new JLabel();
	private JPanel gro�ePanel = new JPanel();
	private Gro�ePanel gro�e = new Gro�ePanel();
	private JButton addButton = new JButton("In Kassenbon zuf�gen");
	private Long id;
	private String farbe;
	private double prise;
	private int mange;

	public EinProdukt() {

		design();
		zusammenBauen();
		addclick();
	}

	private void addclick() {
		addButton.addActionListener(event -> {
			if (gro�e.getGro�e() > 0) {
				CheckinData data = new CheckinData(id, farbe, prise, labeltypeprodukt.getText(), gro�e.getGro�e());
				if (data.checkTypeProdukt(labeltypeprodukt.getText()) == true) {
					Long id_typrProdukt = data.getId_typeProdukt();
					RightFenster right = RightFenster.getInstance();
					right.einBestellungStellen(new EinBestellung(id_typrProdukt, labeltypeprodukt.getText(), prise));
				}

			} else {
				JOptionPane.showMessageDialog(new JFrame(), "bitte w�hlen gro�e", "Achtung", JOptionPane.ERROR_MESSAGE);
			}

		});

	}

	private void design() {
		einprodukt.setPreferredSize(new Dimension(300, 420));
		labelImage.setPreferredSize(new Dimension(280, 250));
		labeltypeprodukt.setPreferredSize(new Dimension(90, 45));
		labelpreis.setPreferredSize(new Dimension(90, 45));
		gro�ePanel.setPreferredSize(new Dimension(180, 45));
		einprodukt.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		// labeltypeprodukt.setBorder(BorderFactory.createLineBorder(new Color(109, 27,
		// 50), 1));
		// labelImage.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50),
		// 1));
		// labelpreis.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50),
		// 1));
		labelpreis.setBackground(Color.yellow);
		labelpreis.setSize(500, 50);
		// labeltypeprodukt.setBackground(Color.yellow);
		labeltypeprodukt.setFont(new Font("Courier New", Font.BOLD, 16));
		labelpreis.setFont(new Font("Courier New", Font.BOLD, 16));
		// gro�ePanel.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50),
		// 1));
		gro�ePanel.setPreferredSize(new Dimension(280, 50));
		addButton.setPreferredSize(new Dimension(280, 50));
		addButton.setBackground(new Color(182, 157, 157));
	}

	private void zusammenBauen() {

		this.add(einprodukt);
		einprodukt.add(labelImage, BorderLayout.CENTER);
		einprodukt.add(labeltypeprodukt, BorderLayout.WEST);
		einprodukt.add(labelpreis, BorderLayout.EAST);
		einprodukt.add(gro�ePanel);
		gro�ePanel.add(gro�e);
		einprodukt.add(addButton);

	}

	public void einProduktStellen(Long id, String farbe, String bathImage, String textTypProdukt, double textPreise) {

		labelImage.setIcon(imageAnzeigen(bathImage));
		labeltypeprodukt.setText(textTypProdukt);
		labelpreis.setText(textPreise + " �");
		this.id = id;
		this.farbe = farbe;
		this.prise = textPreise;

	}

	private ImageIcon imageAnzeigen(String bath) {
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File(bath));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image dimg = img.getScaledInstance(280, 200, Image.SCALE_SMOOTH);

		ImageIcon imageIcon = new ImageIcon(bath);
		return imageIcon;

	}
}
