package de.bekleidungsgeschaeft.fronted;

import java.awt.BorderLayout;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.*;


@SuppressWarnings("serial")
public class JScrollBarDemo extends JPanel{
	JLabel label;

	 public JScrollBarDemo()
	 {
	  super(true);
	  label=new JLabel();
	  setLayout(new BorderLayout());

	  JScrollBar hbar=new JScrollBar(JScrollBar.HORIZONTAL, 0, 0, 0, HauptfensterAPI.MAXIMIZED_HORIZ);
	  JScrollBar vbar=new JScrollBar(JScrollBar.VERTICAL, 0, 0, 0, HauptfensterAPI.MAXIMIZED_VERT);
	  
	  

	  hbar.setUnitIncrement(2);
	  hbar.setBlockIncrement(1);

	  hbar.addAdjustmentListener(new MyAdjustmentListener());
	  vbar.addAdjustmentListener(new MyAdjustmentListener());

	  add(hbar, BorderLayout.SOUTH);
	  add(vbar, BorderLayout.EAST);
	  add(label, BorderLayout.CENTER);
	 }
	 class MyAdjustmentListener implements AdjustmentListener
	 {
	 
	public void adjustmentValueChanged(AdjustmentEvent e) {
		// TODO Auto-generated method stub
		 label.setText("    New Value is " + e.getValue() + "      ");
		   repaint();
		
	}

}
}
