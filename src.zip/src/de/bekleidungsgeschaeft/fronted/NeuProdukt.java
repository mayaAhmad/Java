package de.bekleidungsgeschaeft.fronted;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import de.bekleidungsgeschaeft.backend.ComboBoxSuchen;
import de.bekleidungsgeschaeft.backend.ProduktDAOImpl;
import de.bekleidungsgeschaeft.backend.ProduktDAO;
import de.bekleidungsgeschaeft.middel.ProduktService;
import de.bekleidungsgeschaeft.produkte.Produkt;
/**
 * NeuProdukt Kalsse wenn auf Neu Produkt in Haupt Fenster geclickt wird ,wird dises Klasse angziegt 
 * Vererbung von JFrame Klasse 
 * 
 * @author maya
 *
 */


@SuppressWarnings("serial")
public class NeuProdukt extends JFrame {
	
	
	private JPanel sucheByartikelNrPanle=new JPanel();
	private ComboBoxSuchen sucheByartikelNr=new ComboBoxSuchen(sucheByartikelNrStellen());
	private JButton addNeuProdukButtont=new JButton("Neu Produkt zuf�gen");
	private JPanel produkt=new JPanel();
	
	
	/**
	 * default Constructors
	 * es wird die neu Prdoukt Fenster zusammen gebaut
	 */
	
	public NeuProdukt() {
		setTitle("Neu Produkt Hinzuf�gen");
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
	 
		zusammenBauen();
		clickAddNeuProduktzwei();
		selectedArtikelNr();

	}
/**
 * wenn ein ArtickelNr in ComboBox gew�hlt wird ,wird ander Jpnel gezeigt
 * und diese Jpnael in ander Klasse gestellt
 */
	private void selectedArtikelNr() {
		sucheByartikelNr.addActionListener(event->{
			 produkt.removeAll();
			 produkt.add(new SuchenProdukt((String)sucheByartikelNr.getSelectedItem()));
			addNeuProdukButtont.setEnabled(false);
			produkt.updateUI();
		});
		
	}
/**
 * hier wird die Combobox gef�llt und die data von dataBase gekommen werden
 * @return List 
 */
	private List<String> sucheByartikelNrStellen() {
		List <String> produktatrikelNr =new ArrayList<String>();
		 ProduktDAO produkt=new ProduktDAOImpl();
		 List<Produkt> allProdukt ;
		 ProduktService service=new ProduktService(produkt);
		 allProdukt=service.getAlleProdukt();
		 produktatrikelNr.add("");
		 for(Produkt p : allProdukt) {
			 produktatrikelNr.add(p.getArtikelNr());
			}
		 return produktatrikelNr;
	}


/**
 * 	Action Listener in dieses Methode wenn aud button gecklickt,wird all information in Elemments dises Klasse gescribt in DataBase gespischt	
 */

	private void clickAddNeuProduktzwei() {
		addNeuProdukButtont.addActionListener(event->{
			 produkt.removeAll();
			produkt.add(new NeuProduktZwei());
			addNeuProdukButtont.setEnabled(false);
			produkt.updateUI();
			
		});

	}



/**
 * all Component wird hire zusammen gebaut 
 */

	private void zusammenBauen() {

		this.add(sucheByartikelNrPanle,BorderLayout.NORTH);
		sucheByartikelNrPanle.add(sucheByartikelNr,BorderLayout.WEST);
		sucheByartikelNrPanle.add(addNeuProdukButtont,BorderLayout.WEST);
		this.add(produkt,BorderLayout.CENTER);

		
	
		
	}
	
	
	

}
