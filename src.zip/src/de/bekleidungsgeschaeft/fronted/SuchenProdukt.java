package de.bekleidungsgeschaeft.fronted;

import java.awt.*;
import javax.swing.*;
import de.bekleidungsgeschaeft.backend.*;
import de.bekleidungsgeschaeft.middel.*;
import de.bekleidungsgeschaeft.produkte.*;
/**
 * SuchenProdukt Klasse ist Vererbung von JPanel 
 * es wird Produkt in DataBase angzeigt bei Artikel Nummer 
 * Artikle nummer wird in ander Kalsse geKommt
 * @author Alfa
 *
 */
@SuppressWarnings("serial")
public class SuchenProdukt extends JPanel {

	private JPanel produkt = new JPanel();
	private JLabel artikelNrLabel = new JLabel();
	private JLabel artikelNrLabel2 = new JLabel("Artikel Nummer");
	private JLabel materialLabel = new JLabel();
	private JLabel materialLabel2 = new JLabel("Material");
	private JLabel pflegeLabel = new JLabel();
	private JLabel pflegeLabel2 = new JLabel("Pflege");
	private JLabel preisLabel = new JLabel();
	private JLabel preisLabel2 = new JLabel("Preise");
	private JTextArea produktDetailsLabel = new JTextArea(10, 30);
	private JLabel produktDetailsLabel2 = new JLabel("Produkt Details");
	private JLabel produktTypeLabel = new JLabel();
	private JLabel produktTypeLabel2 = new JLabel("Produkt Type");
	private JButton addDetailsbutton = new JButton("Detail Produkt zuf�gen");
	private String artikelNr;
	private Long idProdukt;

	/**
	 * Artikel Nummer helfet all information in DataBase �ber ein Prdukt zu griefen
	 * @param artikelNr :String...
	 */
	public SuchenProdukt(String artikelNr) {
		this.artikelNr = artikelNr;
		// System.out.println(this.artikelNr);
		design();
		databankenZugriffen();
		zusammenBauen();
		clickAddDetailsButton();
	}
/**
 * diese Methode wird all Component und Element in dises Klasse aufger�umt
 */
	private void design() {
		produkt.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		produkt.setPreferredSize(new Dimension(1600, getMaximumSize().height));
		artikelNrLabel.setPreferredSize(new Dimension(1400, 50));
		artikelNrLabel2.setPreferredSize(new Dimension(100, 50));
		materialLabel.setPreferredSize(new Dimension(1400, 50));
		materialLabel2.setPreferredSize(new Dimension(100, 50));
		pflegeLabel.setPreferredSize(new Dimension(1400, 50));
		pflegeLabel2.setPreferredSize(new Dimension(100, 50));
		preisLabel.setPreferredSize(new Dimension(1400, 50));
		preisLabel2.setPreferredSize(new Dimension(100, 50));
		produktTypeLabel.setPreferredSize(new Dimension(1400, 50));
		produktTypeLabel2.setPreferredSize(new Dimension(100, 50));
		produktDetailsLabel.setPreferredSize(new Dimension(1400, 50));
		//produktDetailsLabel.setEnabled(false);
		produktDetailsLabel.setBackground(new Color(240, 240, 240));
		produktDetailsLabel2.setPreferredSize(new Dimension(100, 50));

	}

	private void clickAddDetailsButton() {
		addDetailsbutton.addActionListener(e -> {
			produkt.add(new DetailsNeuProdukt(idProdukt));
			produkt.updateUI();
		});

	}
/**
 * die Methode wird in dataBase in Kontakt verbeidet und alle information in Component wird gestelt
 */
	private void databankenZugriffen() {
		ProduktDAO produkt = new ProduktDAOImpl();
		Produkt produktByartikelNr;
		ProduktService service = new ProduktService(produkt);

		produktByartikelNr = service.getProduktByartikelNr(produkt, artikelNr);
		idProdukt = produktByartikelNr.getId_produkt();
		artikelNrLabel.setText(produktByartikelNr.getArtikelNr());
		materialLabel.setText(produktByartikelNr.getMaterial());
		
		//pflegeLabel.setText(produktByartikelNr.getPflege());
		pflegeLabel.setIcon(new ImageIcon(produktByartikelNr.getPflege()));
		preisLabel.setText(produktByartikelNr.getPreise() + "�");
		produktTypeLabel.setText(produktByartikelNr.getProduktType());
		produktDetailsLabel.setText(produktByartikelNr.getProduktDetails());

	}
/**
 * All Component in dieses Klasse wird hier gestellt
 */
	private void zusammenBauen() {
		this.add(produkt);
		produkt.add(artikelNrLabel2);
		produkt.add(artikelNrLabel);
		produkt.add(materialLabel2);
		produkt.add(materialLabel);
		produkt.add(pflegeLabel2);
		produkt.add(pflegeLabel);
		produkt.add(preisLabel2);
		produkt.add(preisLabel);
		produkt.add(produktTypeLabel2);
		produkt.add(produktTypeLabel);
		produkt.add(produktDetailsLabel2);
		produkt.add(produktDetailsLabel);
		// this.add(addDetailsPanel);
		produkt.add(addDetailsbutton, BorderLayout.EAST);

	}

}
