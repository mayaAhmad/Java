package de.bekleidungsgeschaeft.fronted;

/**
 * LeftHauptFensterAPI Klasse ist auch die Haupt Fenster  aber nur in die Linke Seilte
 */



import java.awt.*;
import javax.swing.*;


@SuppressWarnings("serial")
public class LeftHauptFensterAPI extends JPanel {
	
	private JPanel leftFenster=new JPanel();
	private JPanel leftFenster1=new JPanel();
	// ist Logo f�r die Programm
	private JLabel labelImage=new JLabel();
	private JButton neuprodukt=new JButton("Neu Produkt Hinzuf�gen");
	
	/**
	 * default Constructors
	 * veile Methode wird in Constructors geanruft
	 */
	public LeftHauptFensterAPI() {
		
		
		clickNeuProdukt();
		zusammenBauen();
		
	}
/**
 * Alle Element in diese Mthode wird aufger�umt
 */
	private void zusammenBauen() {
	//	this.setLayout(new GridLayout(2,1));
		this.setPreferredSize(new Dimension(170,getMaximumSize().height));
		this.add(leftFenster);
		leftFenster.add(labelImage);
		labelImage.setIcon(new ImageIcon("Bilder/logo.jpg"));
		this.add(leftFenster1,1);
		leftFenster1.add(neuprodukt);
		
	}
/**
 * wenn in Button clicken ,w�rde in ander JFrame zeigen
 */
	private void clickNeuProdukt() {
		neuprodukt.addActionListener(e->{
			new NeuProdukt().setVisible(true);
		
		});
		
	}

}
