package de.bekleidungsgeschaeft.fronted;

import javax.swing.*;

import de.bekleidungsgeschaeft.backend.*;
import de.bekleidungsgeschaeft.middel.ProduktService;
import de.bekleidungsgeschaeft.produkte.*;

/**
 * DetailsNeuProdukt Klasse ist Vererbung von JPanel Klasse in das Klass kann
 * man ein produkt type in DataBase stellen aber zuerst muss man all Field in
 * dises Klasse stellt füllen und auf Button clicken
 * 
 * @author Maya
 *
 */
@SuppressWarnings("serial")
public class DetailsNeuProdukt extends JPanel {

	private JPanel panel = new JPanel();
	private JLabel farbeLabel = new JLabel("Farbe");
	private String[] farbeindex = { "Weiß", "Schwaz", "Blue", "Beige", "Rot", "Rot & Rose", "Weiß & Rose" };
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private JComboBox farbeList = new JComboBox(farbeindex);
	private JLabel großeLabel = new JLabel("Große");
	private String[] großeindex = { "Große 34", "Große 36", "Große 38", "Große 40", "Große 42" };
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private JComboBox großeList = new JComboBox(großeindex);
	private JLabel mangeLabel = new JLabel("Mange");
	private JTextField mangeField = new JTextField(15);
	private JButton imagButton = new JButton("Whälen Image");
	private JPanel imagePanel = new JPanel();
	private JButton delletDetailsButton = new JButton("X");
	private JButton addButton = new JButton(" ✔");
	private JTextField imageField1 = new JTextField(15);
	private JTextField imageField2 = new JTextField(15);
	private JTextField imageField3 = new JTextField(15);
	private JTextField imageField4 = new JTextField(15);
	private Long idProdukt;

	/**
	 * default Constructors es wird verschiden Methode angeruft
	 * @param idProdukt id produkt
	 */
	public DetailsNeuProdukt(Long idProdukt) {
		this.idProdukt = idProdukt;
		System.out.println(this.idProdukt);
		zusammenBauen();
	}
	/**
	 * All Component in dieses Klasse wird hier gestellt
	 */
	private void zusammenBauen() {
		this.add(panel);
		panel.setSize(400, 400);
		panel.add(farbeLabel);
		panel.add(farbeList);
		panel.add(großeLabel);
		panel.add(großeList);
		panel.add(mangeLabel);
		panel.add(mangeField);
		imgePanelStellen();
		panel.add(imagePanel);

	}
/**
 * All Images Component in dieses Klasse wird hier gestellt
 */
	private void imgePanelStellen() {

		JLabel imageLabel = new JLabel("Images");
		imagePanel.add(imageLabel);
		imagePanel.add(imageField1);
		imagePanel.add(imageField2);
		imagePanel.add(imageField3);
		imagePanel.add(imageField4);
		imagePanel.add(imagButton);
		imagePanel.add(delletDetailsButton);
		imagePanel.add(addButton);

		clickdeletDetailsButton();
		clikeimageButton();
		clickAddButtn();
	}
/**
 * 
 */
	private void clickAddButtn() {
		addButton.addActionListener(event -> {
			welcheTablleInsert();
			panel.removeAll();
			panel.updateUI();
			JOptionPane.showMessageDialog(new JFrame(), "die Information in dataBase gelegt");

		});

	}

	private void clikeimageButton() {
		imagButton.addActionListener(e -> {
			JFileChooser fc = new JFileChooser();
			@SuppressWarnings("unused")
			int returnVal = fc.showDialog(new FileChooserDemo2(), "Attach");
		});

	}

	private void clickdeletDetailsButton() {

		delletDetailsButton.addActionListener(e -> {
			panel.removeAll();
			panel.updateUI();
		});
	}

	private void welcheTablleInsert() {
		ProduktDAO produkt = new ProduktDAOImpl();
		ProduktService service = new ProduktService(produkt);
		ProduktService serviceType;

		String farbe = (String) farbeList.getSelectedItem();
		String großeString = ((String) großeList.getSelectedItem()).substring(6);
		int große = Integer.parseInt(großeString);
		int mange = Integer.parseInt(mangeField.getText() + 0);
		String[] images = new String[4];
		images[0] = imageField1.getText();
		images[1] = imageField2.getText();
		images[2] = imageField3.getText();
		images[3] = imageField4.getText();

		Produkt produktByID = service.getProduktById(idProdukt);
		String produktType = produktByID.getProduktType();
		System.out.println(produktType);

		switch (produktType) {
		case "Blazer":
			ProduktDAO blazerDAO = new BlazerDAOImpl();
			serviceType = new ProduktService(blazerDAO);
			Blazer neuBlazer = new Blazer(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neuBlazer);
			break;
		case "Bluse":
			ProduktDAO bluseDAO = new BlazerDAOImpl();
			serviceType = new ProduktService(bluseDAO);
			Bluse neubluse = new Bluse(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neubluse);
			break;
		case "Hose":
			ProduktDAO hoseDAO = new HoseDAOImpl();
			serviceType = new ProduktService(hoseDAO);
			Hose neubhose = new Hose(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neubhose);
			break;
		case "Jacke":
			ProduktDAO jackeDAO = new JackeDAOImpl();
			serviceType = new ProduktService(jackeDAO);
			Jacke neubJacke = new Jacke(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neubJacke);
			break;
		case "Jeans":
			ProduktDAO jeansDAO = new JeansDAOImpl();
			serviceType = new ProduktService(jeansDAO);
			Jeans neubJeans = new Jeans(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neubJeans);
			break;
		case "Kleid":
			ProduktDAO kleidDAO = new KleidDAOImpl();
			serviceType = new ProduktService(kleidDAO);
			Kleid neubKleid = new Kleid(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neubKleid);
			break;
		case "Pullover":
			ProduktDAO pulloverDAO = new PulloverDAOImpl();
			serviceType = new ProduktService(pulloverDAO);
			Pullover neubPullover = new Pullover(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neubPullover);
			break;
		case "Roeck":
			ProduktDAO roeckDAO = new RoeckDAOImpl();
			serviceType = new ProduktService(roeckDAO);
			Roeck neubRoeck = new Roeck(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neubRoeck);
			break;
		case "Shirt":
			ProduktDAO shirtDAO = new ShirtDAOImp();
			serviceType = new ProduktService(shirtDAO);
			Shirt neubShirt = new Shirt(idProdukt, farbe, große, mange, images);
			serviceType.insertProudukt(neubShirt);
			break;
		default:
			System.out.println("Kein table in gleisch namen");
			break;
		}

	}

}
