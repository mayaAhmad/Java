package de.bekleidungsgeschaeft.fronted;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.*;

import de.bekleidungsgeschaeft.backend.ProduktDAOImpl;
import de.bekleidungsgeschaeft.backend.ProduktDAO;
import de.bekleidungsgeschaeft.middel.ProduktService;
import de.bekleidungsgeschaeft.produkte.Produkt;
/**
 * NeuProduktZwei Klasse ist Vererbung von JPanel Kalsse 
 * in das Klass kann man ein produkt in DataBase stellen aber zuerst muss man all Field in dises Klasse stellt f�llen und auf Button clicken
 * @author maya
 *
 */
@SuppressWarnings("serial")
public class NeuProduktZwei extends JPanel {

	private JPanel produkt = new JPanel();
	private JPanel artikelNrPanel = new JPanel();
	private JLabel artikelNrLabel = new JLabel("Artikel Nr");
	private JTextField artikelNrText = new JTextField(20);
	private JPanel materialPanel = new JPanel();
	private JLabel materialLabel = new JLabel("Material");
	private JTextField materialText = new JTextField(20);
	private JPanel pflegePanel = new JPanel();
	private JLabel pflegeLabel = new JLabel("Pflege");
	private JTextField pflegeText = new JTextField(20);
	private JButton pflefeImageButton = new JButton("Wh�len Image f�r Pflege");
	private JPanel preisPanel = new JPanel();
	private JLabel preiseLabel = new JLabel("preise");
	private JTextField preiseText = new JTextField(20);
	private JPanel produktDetailsPanel = new JPanel();
	private JLabel produktDetailsLabel = new JLabel("produkt Details");
	private JTextArea produktDetailsText = new JTextArea("Schrein Details Produkt", 10, 30);
	private JPanel produktTypePanel = new JPanel();
	private String[] produktTypeindex = { "Blazer", "Bluse", "Hose", "Jacke", "Jeans", "Kleid", "Pullover", "R�ck",
			"Shirt" };
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private JComboBox produktTypeList = new JComboBox(produktTypeindex);
	private JPanel addDetailsPanel = new JPanel();
	private JButton addDetailsbutton = new JButton("Detail Produkt zuf�gen und speichen diese Produkt");
	@SuppressWarnings("unused")
	private Long idProdukt;

	/**
	 * default Constructors
	 * es wird verschiden Methode angeruft
	 */
	public NeuProduktZwei() {
	
		design();
		zusammenBauen();
		clickPflegeImage();
		clickaAddDetailsButton();
	}
/**
 * diese Methode wird all Component und Element in dises Klasse aufger�umt
 */
	private void design() {
		produkt.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		produkt.setPreferredSize(new Dimension(1600, getMaximumSize().height));
		artikelNrPanel.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		artikelNrPanel.setPreferredSize(new Dimension(700, 50));
		materialPanel.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		materialPanel.setPreferredSize(new Dimension(700, 50));
		pflegePanel.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		pflegePanel.setPreferredSize(new Dimension(700, 50));
		preisPanel.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		preisPanel.setPreferredSize(new Dimension(700, 50));
		produktDetailsPanel.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		produktDetailsPanel.setPreferredSize(new Dimension(700, 170));
		produktTypePanel.setBorder(BorderFactory.createLineBorder(new Color(109, 27, 50), 1));
		produktTypePanel.setPreferredSize(new Dimension(700, 170));
		addDetailsPanel.setPreferredSize(new Dimension(700, 50));
		
	}
/**
 * Action Listener in die Methode ist gestellt , um all information in Field geschriben wird zu dataBase zu speichen
 * es mit DataBase verbindet
 */
	private void clickaAddDetailsButton() {
		addDetailsbutton.addActionListener(e -> {
			ProduktDAO produktDAO = new ProduktDAOImpl();
			Produkt produktByartikelNr;
			ProduktService service = new ProduktService(produktDAO);

			Produkt neuProdukt = new Produkt(produktDetailsText.getText(), materialText.getText(), pflegeText.getText(),
					artikelNrText.getText(), Double.parseDouble(preiseText.getText()),(String)produktTypeList.getSelectedItem());
			service.insertProudukt(neuProdukt);
			String artikel = artikelNrText.getText();
			produktByartikelNr = service.getProduktByartikelNr(produktDAO, artikel);
			//System.out.println(neuProdukt);
			idProdukt = produktByartikelNr.getId_produkt();
			//System.out.println(idProdukt);
			produkt.removeAll();
			produkt.add(new SuchenProdukt(artikel));
			produkt.updateUI();
		});

	}
/**
 *  Action Listener in die Methode ist gestellt, um neu Fenster zuStellen
 *  und ander kalsse rufen
 */
	private void clickPflegeImage() {
		pflefeImageButton.addActionListener(e -> {
			JFileChooser fc = new JFileChooser();
			@SuppressWarnings("unused")
			int returnVal = fc.showDialog(new FileChooserDemo2(), "Attach");
		});

	}
/**
 * All Component in dieses Klasse wird hier gestellt
 */
	private void zusammenBauen() {
		this.add(produkt);
		produkt.add(artikelNrPanel);
		artikelNrPanel.add(artikelNrLabel);
		artikelNrPanel.add(artikelNrText);
		produkt.add(materialPanel);
		materialPanel.add(materialLabel);
		materialPanel.add(materialText);
		produkt.add(pflegePanel);
		pflegePanel.add(pflegeLabel);
		pflegePanel.add(pflegeText);
		produkt.add(preisPanel);
		preisPanel.add(preiseLabel);
		preisPanel.add(preiseText);
		produkt.add(produktDetailsPanel);
		produktDetailsPanel.add(produktDetailsLabel);
		produktDetailsPanel.add(produktDetailsText);
		produkt.add(produktTypePanel);
		produktTypePanel.add(produktTypeList);
		produkt.add(addDetailsPanel);
		addDetailsPanel.add(addDetailsbutton, BorderLayout.EAST);

	}

}
