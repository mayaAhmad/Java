package de.bekleidungsgeschaeft.fronted;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.*;

@SuppressWarnings("serial")
public class Gro�ePanel extends JPanel implements ActionListener{
	

	private JRadioButton radio34 =new JRadioButton("34");
	private JRadioButton radio36 =new JRadioButton("36");
	private JRadioButton radio38 =new JRadioButton("38");
	private JRadioButton radio40 =new JRadioButton("40");
	private JRadioButton radio42 =new JRadioButton("42");
	
	private int gro�e;
	
	//Group the radio buttons.
    private ButtonGroup group = new ButtonGroup();
	
	public Gro�ePanel() {
		//this.setPreferredSize(new Dimension(200, 45));
		radioNamen();
		zusammenBauen();
		clickRadioButton();
	}


	private void clickRadioButton() {
		radio34.addActionListener(this);
		radio36.addActionListener(this);
		radio38.addActionListener(this);
		radio40.addActionListener(this);
		radio42.addActionListener(this);
		
	}


	private void radioNamen() {
		radio34.setMnemonic(KeyEvent.VK_D);
		radio34.setActionCommand("34");
		radio36.setMnemonic(KeyEvent.VK_D);
		radio36.setActionCommand("36");
		radio38.setMnemonic(KeyEvent.VK_D);
		radio38.setActionCommand("38");
		radio40.setMnemonic(KeyEvent.VK_D);
		radio40.setActionCommand("40");
		radio42.setMnemonic(KeyEvent.VK_D);
		radio42.setActionCommand("42");
		
	}


	private void zusammenBauen() {
		this.add(radio34);
		this.add(radio36);
		this.add(radio38);
		this.add(radio40);
		this.add(radio42);
		group.add(radio34);
		group.add(radio36);
		group.add(radio38);
		group.add(radio40);
		group.add(radio42);
		
	}


	public int getGro�e() {
		return gro�e;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		gro�e= Integer.parseInt(e.getActionCommand());
	//	System.out.println(gro�e);
	
		
	}

}
