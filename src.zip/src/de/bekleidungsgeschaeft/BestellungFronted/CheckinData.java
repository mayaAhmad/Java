package de.bekleidungsgeschaeft.BestellungFronted;

import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import de.bekleidungsgeschaeft.backend.*;
import de.bekleidungsgeschaeft.middel.ProduktService;
import de.bekleidungsgeschaeft.produkte.*;

public class CheckinData {
	private Long id;
	private String farbe;
	private double prise;
	private String typeProdukt;
	private int gro�e;
	private Produkt produkt;
	private Long id_typeProdukt;

	public CheckinData(Long id, String farbe, double prise, String typeProdukt, int gro�e) {
		this.id = id;
		this.farbe = farbe;
		this.prise = prise;
		this.typeProdukt = typeProdukt;
		this.gro�e = gro�e;
		
	}

	public Long getId_typeProdukt() {
		return id_typeProdukt;
	}

	public boolean checkTypeProdukt(String typeProdukt) {
		boolean b;

		switch (typeProdukt) {
		case "Blazer":
			b = beindenBeiBlazer();
			return b;
		case "Bluse":
			b=beindenBeiBluse();

			return b;
		case "Hose":
			b=beindenBeiHose();
			return b;

		case "Jacke":
			b=beindenBeiJacke();
			return b;
		case "Jeans":
			b=beindenBeiJeans();
			return b;
		case "Kleid":
			b=beindenBeiKleid();
			return b;
		case "Pullover":
			b=beindenBeipullover();
			return b;
		case "Roeck":
			b=beindenBeiRoeck();
			return b;
		case "Shirt":
			b=beindenBeiShirt();
			return b;

		default:
			System.out.println("bay");

			return false;
		}
	}

	@SuppressWarnings("unused")
	private boolean beindenBeiBlazer() {
		ProduktDAO qulleBlazer = new BlazerDAOImpl();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qulleBlazer);
		Blazer produktBlazr = (Blazer) service.getAllemange(id, farbe, gro�e);
		//System.out.print(id_typeProdukt);
		if (produktBlazr == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			if (produktBlazr.getMange() > 0) {
				this.id_typeProdukt = produktBlazr.getId_blazer();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

	private boolean beindenBeiBluse() {
		ProduktDAO qulleBluse = new BluseDAOImpl();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qulleBluse);
		Bluse produktBluse = (Bluse) service.getAllemange(id, farbe, gro�e);
		if (produktBluse == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			this.id_typeProdukt = produktBluse.getId_bluse();
			if (produktBluse.getMange() > 0) {
				getId_typeProdukt();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

	private boolean beindenBeiHose() {
		ProduktDAO qulleHose = new HoseDAOImpl();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qulleHose);
		Hose produktHose = (Hose) service.getAllemange(id, farbe, gro�e);
		if (produktHose == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			id_typeProdukt = produktHose.getId_hose();
			if (produktHose.getMange() > 0) {
				getId_typeProdukt();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

	private boolean beindenBeiJeans() {
		ProduktDAO qulleJeans = new JeansDAOImpl();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qulleJeans);
		Jeans produktJeans = (Jeans) service.getAllemange(id, farbe, gro�e);
		if (produktJeans == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			id_typeProdukt = produktJeans.getId_jeans();
			if (produktJeans.getMange() > 0) {
				getId_typeProdukt();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

	private boolean beindenBeiJacke() {
		ProduktDAO qulleJacke = new JackeDAOImpl();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qulleJacke);
		Jacke produktJacke = (Jacke) service.getAllemange(id, farbe, gro�e);
		if (produktJacke == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			id_typeProdukt = produktJacke.getId_jacke();
			if (produktJacke.getMange() > 0) {
				getId_typeProdukt();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

	private boolean beindenBeiKleid() {
		ProduktDAO qulleKleid = new KleidDAOImpl();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qulleKleid);
		Kleid produktKleid = (Kleid) service.getAllemange(id, farbe, gro�e);
		if (produktKleid == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			id_typeProdukt = produktKleid.getId_kleid();
			if (produktKleid.getMange() > 0) {
				getId_typeProdukt();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

	private boolean beindenBeipullover() {
		ProduktDAO qullePullover = new PulloverDAOImpl();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qullePullover);
		Pullover produktPullover = (Pullover) service.getAllemange(id, farbe, gro�e);
		if (produktPullover == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			id_typeProdukt = produktPullover.getId_pullover();
			if (produktPullover.getMange() > 0) {
				getId_typeProdukt();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

	private boolean beindenBeiRoeck() {
		ProduktDAO qulleRoeck = new RoeckDAOImpl();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qulleRoeck);
		Roeck produktRoeck = (Roeck) service.getAllemange(id, farbe, gro�e);
		if (produktRoeck == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			id_typeProdukt = produktRoeck.getId_roeck();
			if (produktRoeck.getMange() > 0) {
				getId_typeProdukt();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

	private boolean beindenBeiShirt() {
		ProduktDAO qulleShirt = new ShirtDAOImp();
		List<Produkt> alle;
		ProduktService service = new ProduktService(qulleShirt);
		Shirt produktShirt = (Shirt) service.getAllemange(id, farbe, gro�e);
		
		if (produktShirt == null) {
			JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");
			return false;
		} else {
			id_typeProdukt = produktShirt.getId_shirt();
			if (produktShirt.getMange() > 0) {
				getId_typeProdukt();

				return true;
			} else {
				JOptionPane.showMessageDialog(new JFrame(), "Kein dises gro�e.");

			}
			return false;
		}

	}

}
