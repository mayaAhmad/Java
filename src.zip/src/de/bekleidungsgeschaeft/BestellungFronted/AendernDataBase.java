package de.bekleidungsgeschaeft.BestellungFronted;



import de.bekleidungsgeschaeft.backend.*;
import de.bekleidungsgeschaeft.middel.ProduktService;


public class AendernDataBase {
	private Long id_prdouktType;
	private String produktType;
	private String aendern;
	
	
	public AendernDataBase(Long id_prdouktType,String produktType,String aendern) {
		this.id_prdouktType=id_prdouktType;
		this.produktType=produktType;
		this.aendern=aendern;
		aedernMangeInDataBase(produktType);
	}


	private void aedernMangeInDataBase(String produktType) {
		switch (produktType) {
		case "Blazer":
			aedernMangeInBlazer();
			break;
		case "Bluse":
			aedernMangeInBluse();
			break;
		case "Hose":
			aedernMangeInHose();
			break;
		case "Jacke":
			aedernMangeInJacke();
			break;
		case "Jeans":
			aedernMangeInJeans();
			break;
		case "Kleid":
			aedernMangeInKleid();
			break;
		case "Pullover":
			aedernMangeInpullover();
			break;
		case "Roeck":
			aedernMangeInRoeck();
			break;
		case "Shirt":
			aedernMangeInShirt();
			break;

		default:
			System.out.println("bay");

			break;
		}
	}


	private void aedernMangeInBlazer() {
		ProduktDAO qulleBlazer = new BlazerDAOImpl();
		ProduktService service = new ProduktService(qulleBlazer);
		service.updateMange(id_prdouktType,aendern);
	}


	private void aedernMangeInBluse() {
		ProduktDAO qulleBluse = new BluseDAOImpl();
		ProduktService service = new ProduktService(qulleBluse);
		service.updateMange(id_prdouktType,aendern);
	}


	private void aedernMangeInHose() {
		ProduktDAO qulleHose = new HoseDAOImpl();
		ProduktService service = new ProduktService(qulleHose);
		service.updateMange(id_prdouktType,aendern);
	}


	private void aedernMangeInJacke() {
		ProduktDAO qulleJacke = new JackeDAOImpl();
		ProduktService service = new ProduktService(qulleJacke);
		service.updateMange(id_prdouktType,aendern);
	}


	private void aedernMangeInJeans() {
		ProduktDAO qulleJeans = new JeansDAOImpl();
		ProduktService service = new ProduktService(qulleJeans);
		service.updateMange(id_prdouktType,aendern);
	}


	private void aedernMangeInKleid() {
		ProduktDAO qulleKleid = new KleidDAOImpl();
		ProduktService service = new ProduktService(qulleKleid);
		service.updateMange(id_prdouktType,aendern);
	}


	private void aedernMangeInpullover() {
		ProduktDAO qullePullover = new PulloverDAOImpl();
		ProduktService service = new ProduktService(qullePullover);
		service.updateMange(id_prdouktType,aendern);
	}


	private void aedernMangeInRoeck() {
		ProduktDAO qulleRoeck = new RoeckDAOImpl();
		ProduktService service = new ProduktService(qulleRoeck);
		service.updateMange(id_prdouktType,aendern);
	}


	private void aedernMangeInShirt() {
		ProduktDAO qulleShirt = new ShirtDAOImp();
		ProduktService service = new ProduktService(qulleShirt);
		service.updateMange(id_prdouktType,aendern);
	}
		
		
		

}
