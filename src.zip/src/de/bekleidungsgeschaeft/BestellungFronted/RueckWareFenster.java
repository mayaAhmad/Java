package de.bekleidungsgeschaeft.BestellungFronted;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import de.bekleidungsgeschaeft.besttellung.Bestellung;

public class RueckWareFenster  extends JFrame{
	
	private JPanel panel=new JPanel();
	private JPanel okPanel = new JPanel();
	private JButton ok=new JButton("OK");
	private static RueckWareFenster ruoeckFenster;
	private  List<Bestellung> bestellungs=new ArrayList<Bestellung>();
	private  List<Bestellung> bestellungszuruck=new ArrayList<Bestellung>();
	
	
	
	private  RueckWareFenster() {
		setTitle("R�ck Ware");
		this.setSize(400,700);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		zusammenBauen();
		desing();
		okClick();
		//kassenBonStellen();
		

	}
	
	private void okClick() {
		ok.addActionListener(e->{
			for (int i = 0; i < bestellungszuruck.size(); i++) {
				new AendernDataBase((bestellungszuruck.get(i)).getId_produkttype(), (bestellungszuruck.get(i)).getProdukttype(),"+");
			//	JOptionPane.showMessageDialog(new JFrame(), "die arbeitung wurde gespiecht");
				bestellungszuruck.remove(bestellungszuruck.get(i));
				panel.removeAll();
				ruoeckFenster.dispatchEvent(new WindowEvent(ruoeckFenster, WindowEvent.WINDOW_CLOSING));
			}
		});
	}

	public static RueckWareFenster getInstance() {
		if (ruoeckFenster == null) {
			ruoeckFenster = new RueckWareFenster();
		}
		return ruoeckFenster;
	}

	public void kassenBonStellen(List<Bestellung> bestel) {
		this.bestellungs=bestel;
		for (int i = 0; i < bestellungs.size(); i++) {
		panel.add(new RueckWare(bestellungs.get(i)));
	}
		for (int i = 0; i < bestellungs.size(); i++) {
			bestellungs.remove(bestellungs.get(i));
		}
		
	}

	private void desing() {
		panel.setPreferredSize(new Dimension(350,600));
		okPanel.setPreferredSize(new Dimension(340, 40));
		ok.setPreferredSize(new Dimension(300, 40));
		
	}

	private void zusammenBauen() {
		this.add(panel);
		this.add(okPanel,BorderLayout.SOUTH);
		okPanel.add(ok);
		
	}

	public void wareZuruck(Bestellung be) {
		bestellungszuruck.add(be);
		
	}

}
