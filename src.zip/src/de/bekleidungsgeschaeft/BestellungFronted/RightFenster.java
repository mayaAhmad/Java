package de.bekleidungsgeschaeft.BestellungFronted;

import java.awt.*;
import javax.swing.*;

import java.util.ArrayList;
import java.util.List;

import de.bekleidungsgeschaeft.BestellungBackend.BestellungDAO;
import de.bekleidungsgeschaeft.BestellungBackend.BestellungDAOImpl;
import de.bekleidungsgeschaeft.besttellung.Bestellung;
import de.bekleidungsgeschaeft.middel.BestellungService;

@SuppressWarnings("serial")
public class RightFenster extends JPanel {

	private JPanel kassenBon = new JPanel();
	private JPanel bestellung = new JPanel();
	private JLabel kassenBonLabel = new JLabel("KassenBon");
	private JTextField suchenText=new JTextField(15);
	private JButton suchenButton=new JButton("suchen");
	private JLabel idproduktType = new JLabel("Nummer");
	private JLabel produktType = new JLabel("Prdoukt");
	private JLabel preiseStuckLabel = new JLabel("Preise");
	private JPanel totalPanel = new JPanel();
	private JLabel totalLabel = new JLabel("Total");
	private JLabel zahlLabel = new JLabel("");
	private JButton zahlenButton = new JButton("Zahlen");
	private List<Bestellung> bestellungs = new ArrayList<Bestellung>();
	private double total;
	private  int id_kassenBon ;

	private static RightFenster rightfinster;

	private RightFenster() {

		zusammenBauen();
		design();
		clickZahlenButton();
		clickSuchenButton();

	}

	private void clickSuchenButton() {
		suchenButton.addActionListener(e->{
			BestellungDAO bestellungDAO = new BestellungDAOImpl();
			BestellungService service = new BestellungService(bestellungDAO);
			int kassen=Integer.parseInt(suchenText.getText());
			bestellungs=service.getAllBestellung(kassen);
			
			RueckWareFenster fenster=RueckWareFenster.getInstance();
			fenster.kassenBonStellen(bestellungs);
			fenster.setVisible(true);
		});
		
	}

	private void clickZahlenButton() {
		zahlenButton.addActionListener(e -> {
			BestellungDAO bestellungDAO = new BestellungDAOImpl();
			BestellungService service = new BestellungService(bestellungDAO);
			id_kassenBon=service.getMaxIdKassenBon();
			for (int i = 0; i < bestellungs.size(); i++) {
				(bestellungs.get(i)).setId_kassenbonn(id_kassenBon+1);
				service.insertBestellung(bestellungs.get(i));
				new AendernDataBase((bestellungs.get(i)).getId_produkttype(),(bestellungs.get(i)).getProdukttype(),"-");
			}
			weiderZusammenBauen();
		});
	}

	private void weiderZusammenBauen() {
		id_kassenBon++;
		kassenBon.removeAll();
		kassenBon.add(idproduktType);
		kassenBon.add(produktType);
		kassenBon.add(preiseStuckLabel);
		zahlLabel.setText("");
		kassenBon.updateUI();
		JOptionPane.showMessageDialog(new JFrame(), "Danke f�r Kaufen","beenden",
			    JOptionPane.INFORMATION_MESSAGE);
		for (int i = 0; i < bestellungs.size(); i++) {
			bestellungs.remove(bestellungs.get(i));
		}
		total=0.0;
		
	}

	public static RightFenster getInstance() {
		if (rightfinster == null) {
			rightfinster = new RightFenster();
		}
		return rightfinster;
	}

	private void design() {

		this.setPreferredSize(new Dimension(300, 1000));

		// Bestellung JPanel
		bestellung.setPreferredSize(new Dimension(300, 100));
		bestellung.setBorder((BorderFactory.createLineBorder(new Color(109, 27, 50), 1)));
		kassenBonLabel.setPreferredSize(new Dimension(300, 60));
		suchenText.setPreferredSize(new Dimension(150, 28));
		kassenBonLabel.setFont(new Font("Courier New", Font.BOLD, 16));

		// KassenBon
		kassenBon.setBorder((BorderFactory.createLineBorder(new Color(109, 27, 50), 1)));
		kassenBon.setPreferredSize(new Dimension(300, 800));

		// kassenBon.setLayout(new GridLayout(5,1));
		idproduktType.setPreferredSize(new Dimension(90, 50));
		produktType.setPreferredSize(new Dimension(90, 50));
		preiseStuckLabel.setPreferredSize(new Dimension(90, 50));
		produktType.setFont(new Font("Courier New", Font.BOLD, 16));
		preiseStuckLabel.setFont(new Font("Courier New", Font.BOLD, 16));
		idproduktType.setFont(new Font("Courier New", Font.BOLD, 16));

		// TotalPreise
		totalPanel.setBorder((BorderFactory.createLineBorder(new Color(109, 27, 50), 1)));
		totalPanel.setPreferredSize(new Dimension(300, 50));
		totalLabel.setFont(new Font("Courier New", Font.BOLD, 16));
		totalLabel.setPreferredSize(new Dimension(80, 50));
		zahlLabel.setPreferredSize(new Dimension(80, 50));
		zahlLabel.setFont(new Font("Courier New", Font.BOLD, 16));

	}

	private void zusammenBauen() {
		this.add(bestellung, BorderLayout.NORTH);
		this.add(kassenBon);
		bestellung.add(kassenBonLabel);
		bestellung.add(suchenText);
		bestellung.add(suchenButton);
		//KasenBon
		kassenBon.add(idproduktType);
		kassenBon.add(produktType);
		kassenBon.add(preiseStuckLabel);
		//totalPanel
		this.add(totalPanel, BorderLayout.SOUTH);
		totalPanel.add(totalLabel);
		totalLabel.add(zahlLabel);
		totalPanel.add(zahlenButton, BorderLayout.EAST);

	}

	public void einBestellungStellen(EinBestellung stell) {
		kassenBon.add(stell);
		kassenBon.updateUI();

	}

	public void zahlen(Bestellung bestellung) {
		zahlLabel.setText("");
		total += bestellung.getPreise();
		bestellungs.add(bestellung);

		zahlLabel.setText(total + "");
		totalPanel.add(zahlLabel);
		totalPanel.updateUI();

	}

	public void deleteEinBestellung(Bestellung bestellung) {
		total -= bestellung.getPreise();
		zahlLabel.setText(total + "");
		totalPanel.add(zahlLabel);
		totalPanel.updateUI();
		for (int i = 0; i < bestellungs.size(); i++) {
			(bestellungs.get(i)).equals(bestellung);
			bestellungs.remove(bestellung);
			break;
		}

	}

}
