package de.bekleidungsgeschaeft.BestellungFronted;
	import java.awt.*;
	import java.util.ArrayList;
	import java.util.List;

	import javax.swing.*;

	import de.bekleidungsgeschaeft.besttellung.Bestellung;

	
@SuppressWarnings("serial")
public class RueckWare extends JPanel{


		private JPanel panel = new JPanel();
		private JLabel id = new JLabel();
		private JLabel type = new JLabel();
		private JLabel preis = new JLabel();
		private JButton x = new JButton("✔");
	
		private RueckWareFenster fenster=RueckWareFenster.getInstance();
		private static List<Bestellung> bestellungs = new ArrayList<Bestellung>();
		private Bestellung einsBestellung;
		private double preise;




	//	public RueckWare(Long id_typeProdukt, String typePr, double prise) {
		public RueckWare(Bestellung bestellung) {
			einsBestellung=bestellung;

			id.setText(einsBestellung.getId_produkttype() + "");
			type.setText(einsBestellung.getProdukttype());
			preis.setText(einsBestellung.getPreise() + "€");
			this.preise = einsBestellung.getPreise();
			bestellungs.add(einsBestellung);
			desing();
			zusammenBauen();
			clickXButton();
			
		}



		private void clickXButton() {
			x.addActionListener(e -> {
				Bestellung be = new Bestellung(Long.parseLong(id.getText()),type.getText(), 0, preise);
				bestellungs.forEach(obj->{
					if(obj.equals(be)) {
						//bestellungsZuruck.add(be);
						fenster.wareZuruck(be);
					}
				});
				panel.setBackground(new Color(172, 182, 127));
				x.setVisible(false);
				panel.updateUI();
			});

		}
		
		

		private void desing() {
			// panel.setBorder((BorderFactory.createLineBorder(new Color(109, 27, 50), 1)));
			panel.setPreferredSize(new Dimension(280, 40));
			id.setFont(new Font("Courier New", Font.BOLD, 16));
			id.setPreferredSize(new Dimension(50, 40));
			type.setFont(new Font("Courier New", Font.BOLD, 16));
			type.setPreferredSize(new Dimension(80, 40));
			preis.setFont(new Font("Courier New", Font.BOLD, 16));
			preis.setPreferredSize(new Dimension(80, 40));

		}

		private void zusammenBauen() {
			
			this.add(panel);
			panel.add(x, BorderLayout.WEST);
			panel.add(id);
			panel.add(type);
			panel.add(preis);
			
			
			

		}

	}
