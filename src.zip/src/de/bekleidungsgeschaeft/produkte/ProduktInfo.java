package de.bekleidungsgeschaeft.produkte;

public interface ProduktInfo {
	public String getProduktInfo();

}
