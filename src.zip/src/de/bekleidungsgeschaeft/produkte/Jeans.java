package de.bekleidungsgeschaeft.produkte;

import java.util.Arrays;

/**
 * Kalsse Bluse ist ein type von Produkt Objeckt Vererbung von Produkt object
 * 
 * @author maya
 *
 */
public class Jeans extends Produkt implements ProduktInfo {

	protected Long id_jeans;
	protected Long id_produkt;
	private String farbe;
	private int gro�e;
	private int mange;
	private String[] image = new String[4];

	/**
	 * default Constructors
	 */

	public Jeans() {

	}

	/**
	 * 
	 * @param id_produktist Long type , das parmeter k�nnten wir mit id_produkt in
	 *                      produkt Klasse verbinden ist ein foren Key
	 * @param farbe         ist String type ,jeader produkt hat farbe
	 * @param gro�e         ist int type, weleches gro�e hat dieses Jeans
	 * @param mange         ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image         ist ein Array String type ,es wird alle images von Jeans
	 *                      in array gespeischt
	 */
	public Jeans(Long id_produkt, String farbe, int gro�e, int mange, String[] image) {
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		produktType = "Jeans";
	}

	/**
	 * @param id_jeans      ist Long Type, jeades hat einzig nummer und das ist
	 *                      primary key in DataBase
	 * @param id_produktist Long type , das parmeter k�nnten wir mit id_produkt in
	 *                      produkt Klasse verbinden ist ein foren Key
	 * @param farbe         ist String type ,jeader produkt hat farbe
	 * @param gro�e         ist int type, weleches gro�e hat dieses Jeans
	 * @param mange         ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image         ist ein Array String type ,es wird alle images von Jeans
	 *                      in array gespeischt
	 */
	public Jeans(Long id_jeans, Long id_produkt, String farbe, int gro�e, int mange, String[] image) {
		this.id_jeans = id_jeans;
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		produktType = "Jeans";
	}

	/**
	 * 
	 * @param id_jeans      ist Long Type, jeades hat einzig nummer und das ist
	 *                      primary key in DataBase
	 * @param id_produktist Long type , das parmeter k�nnten wir mit id_produkt in
	 *                      produkt Klasse verbinden ist ein foren Key
	 * @param farbe         ist String type ,jeader produkt hat farbe
	 * @param gro�e         ist int type, weleches gro�e hat dieses Jeans
	 * @param mange         ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image         ist ein Array String type ,es wird alle images von Jeans
	 *                      in array gespeischt
	 * @param produktType   ist String type , es wird hier Jeans gespiecht
	 */
	public Jeans(Long id_jeans, Long id_produkt, String farbe, int gro�e, int mange, String[] image, double preise,
			String produktType) {
		this.id_jeans = id_jeans;
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		this.preise = preise;
		this.produktType = produktType;
	}

	/**
	 * diese Konstruktor halfen uns in dataBase zu verbenden
	 * 
	 * @param id_jeans ...
	 * @param mange ...
	 */
	public Jeans(Long id_jeans, int mange) {
		this.id_jeans = id_jeans;
		this.mange = mange;
	}

	/**
	 * ein Mthode ,die einige Data in objeck griefen
	 */
	public String getProduktInfo() {

		return "Preis " + preise + "\n" + "Farbe: " + this.farbe + "\n" + "Gro�e: " + this.gro�e + "\n"
				+ "Produkt Details: " + produktDetails + "\n" + "Artkel-Nr: " + artikelNr + "\n" + "Material: "
				+ material + "\n" + "Pflege: " + pflege + "\n";
	}
/**
 * Getter Methode
 * @return image:String[]
 */
	public String[] getImage() {
		return image;
	}
/**
 * Setter Methode
 * @param image: String[]
 */
	public void setImage(String[] image) {
		this.image = image;
	}
	/**
	 * Getter Methode
	 * @return id_jeans:Long
	 */
	public Long getId_jeans() {
		return id_jeans;
	}
	/**
	 * Getter Methode
	 * @return id_produkt:Long
	 */
	public Long getId_produkt() {
		return id_produkt;
	}
/**
 * Setter Methode
 * @param farbe:String
 */
	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}

	public void setGro�e(int gro�e) {
		this.gro�e = gro�e;
	}
	/**
	 * Getter Methode
	 * @return farbe:String
	 */
	public String getFarbe() {
		return farbe;
	}
	/**
	 * Getter Methode
	 * @return gro�e:int
	 */
	public int getGro�e() {
		return gro�e;
	}
	/**
	 * Getter Methode
	 * @return mange:int
	 */
	public int getMange() {
		return mange;
	}
/**
 * Setter Methode
 * @param mange:int
 */
	public void setMange(int mange) {
		this.mange = mange;
	}

	@Override
	public String toString() {
		return "Jeans [id_jeans=" + id_jeans + ", id_produkt=" + id_produkt + ", farbe=" + farbe + ", gro�e=" + gro�e
				+ ", mange=" + mange + ", image=" + Arrays.toString(image) + ", preise=" + preise + ", produktType="
				+ produktType + "]";
	}

}
