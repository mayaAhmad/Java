package de.bekleidungsgeschaeft.produkte;

/**
 * Produkt Klass ist ein klassen in diese Program neu Produkt kann stellen mit
 * setter und getter die variablen wird es gestellt ung gegriffen
 * 
 */
public class Produkt {
	protected Long id_produkt;
	protected String produktDetails;
	protected String material;
	protected String pflege;
	protected String artikelNr;
	protected double preise;
	protected String produktType;

	/**
	 * default Constructors
	 */
	public Produkt() {

	}

	/**
	 * 
	 * @param produktDetails ist String type ,Beschreibung das produkt
	 * @param material       ist String type , weleches material wird das produkt
	 *                       gemacht
	 * @param pflege         ist String type, wie kann man dieses produkt benutzen
	 * @param artikelNr      ist String , jeades produkt hat ein artikel nummer ,das
	 *                       in der lage kommt
	 * @param preise         ist double type , preise f�r produkt
	 * @param produktType    ist String type ,gibt es verschieden type
	 */
	public Produkt(String produktDetails, String material, String pflege, String artikelNr, double preise,
			String produktType) {
		this.produktDetails = produktDetails;
		this.material = material;
		this.pflege = pflege;
		this.artikelNr = artikelNr;
		this.preise = preise;
		this.produktType = produktType;

	}

	/**
	 * 
	 * @param id_produkt     ist Long type , jeades produkt hat einzig Nummer
	 * @param produktDetails ist String type ,Beschreibung das produkt
	 * @param material       ist String type , weleches material wird das produkt
	 *                       gemacht
	 * @param pflege         ist String type, wie kann man dieses produkt benutzen
	 * @param artikelNr      ist String , jeades produkt hat ein artikel nummer ,das
	 *                       in der lage kommt
	 * @param preise         ist double type , preise f�r produkt
	 * @param produktType    ist String type ,gibt es verschieden type
	 */

	public Produkt(Long id_produkt, String produktDetails, String material, String pflege, String artikelNr,
			double preise, String produktType) {
		this.id_produkt = id_produkt;
		this.produktDetails = produktDetails;
		this.material = material;
		this.pflege = pflege;
		this.artikelNr = artikelNr;
		this.preise = preise;
		this.produktType = produktType;

	}

	/**
	 * Getter Methode
	 * @return id_produkt
	 */
	public Long getId_produkt() {
		return id_produkt;
	}

	/**
	 * 
	 * @return produktDetails
	 */
	public String getProduktDetails() {
		return produktDetails;
	}

	/**
	 * setter Methode
	 * 
	 * @param produktDetails :String
	 */
	public void setProduktDetails(String produktDetails) {
		this.produktDetails = produktDetails;
	}

	/**
	 * getter ethodde
	 * 
	 * @return material :String
	 */
	public String getMaterial() {
		return material;
	}
/**
 * setter Methode
 * @param material :String
 */
	public void setMaterial(String material) {
		this.material = material;
	}
/**
 * getter Methode
 * @return pflege:String
 */
	public String getPflege() {
		return pflege;
	}
/**
 * setter Methode
 * @param pflege :String
 */
	public void setPflege(String pflege) {
		this.pflege = pflege;
	}
/**
 * getter Methode
 * @return artikelNr :String
 */
	public String getArtikelNr() {
		return artikelNr;
	}
/**
 * getter Methode
 * @return preise :double
 */
	public double getPreise() {
		return preise;
	}
/**
 * getter Methode
 * @return produktType :String
 */
	public String getProduktType() {
		return produktType;
	}
/**
 * ToString Methode, in diese Methode wird es alle vraiablen geschrieben
 */
	@Override
	public String toString() {
		return "Produkt [id_produkt=" + id_produkt + "\r\nproduktDetails=" + produktDetails + "\r\n material="
				+ material + "\r\n pflege=" + pflege + "\r\nartikelNr=" + artikelNr + "\r\n preise=" + preise
				+ "\r\n produktType=" + produktType + "]";
	}

}
