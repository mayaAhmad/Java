package de.bekleidungsgeschaeft.produkte;

import java.util.Arrays;

/**
 * Kalsse Pullover ist ein type von Produkt Objeckt Vererbung von Produkt object
 * 
 * @author maya
 *
 */
public class Pullover extends Produkt implements ProduktInfo {

	protected Long id_pullover;
	protected Long id_produkt;
	private String farbe;
	private int gro�e;
	private int mange;
	private String[] image = new String[4];

	/**
	 * default Constructors
	 */
	public Pullover() {

	}

	/**
	 * 
	 * @param id_pulloverist Long Type, Pullover hat einzig nummer und das ist
	 *                       primary key in DataBase
	 * @param id_produkt     ist Long type , das parmeter k�nnten wir mit id_produkt
	 *                       in produkt Klasse verbinden ist ein foren Key
	 * @param farbe          ist String type ,jeader produkt hat farbe
	 * @param gro�e          ist int type, weleches gro�e hat dieses Pullover
	 * @param mange          ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image          ist ein Array String type ,es wird alle images von
	 *                       Pullover in array gespeischt
	 */
	public Pullover(Long id_pullover, Long id_produkt, String farbe, int gro�e, int mange, String[] image) {
		this.id_pullover = id_pullover;
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		produktType = "Pullover";
	}

	/**
	 * 
	 * @param id_produkt ist Long type , das parmeter k�nnten wir mit id_produkt in
	 *                   produkt Klasse verbinden ist ein foren Key
	 * @param farbe      ist String type ,jeader produkt hat farbe
	 * @param gro�e      ist int type, weleches gro�e hat dieses Pullover
	 * @param mange      ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image      ist ein Array String type ,es wird alle images von Pullover
	 *                   in array gespeischt
	 */
	public Pullover(Long id_produkt, String farbe, int gro�e, int mange, String[] image) {
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		produktType = "Pullover";
	}

	/**
	 * 
	 * @param id_pulloverist Long Type, Pullover hat einzig nummer und das ist
	 *                       primary key in DataBase
	 * @param id_produkt     ist Long type , das parmeter k�nnten wir mit id_produkt
	 *                       in produkt Klasse verbinden ist ein foren Key
	 * @param farbe          ist String type ,jeader produkt hat farbe
	 * @param gro�e          ist int type, weleches gro�e hat dieses Pullover
	 * @param mange          ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image          ist ein Array String type ,es wird alle images von
	 *                       Pullover in array gespeischt
	 * @param produktType    ist String type , es wird hier Pullover gespiecht
	 */
	public Pullover(long id_pullover, Long id_produkt, String farbe, int gro�e, int mange, String[] image,
			double preise, String produktType) {
		this.id_pullover = id_pullover;
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		this.preise = preise;
		this.produktType = produktType;
	}

	/**
	 * diese Konstruktor halfen uns in dataBase zu verbenden
	 * 
	 * @param id_pullover ...
	 * @param mange ...
	 */
	public Pullover(Long id_pullover, int mange) {
		this.id_pullover = id_pullover;
		this.mange = mange;
	}

	/**
	 * ein Mthode ,die einige Data in objeck griefen
	 */
	public String getProduktInfo() {

		return "Preis " + preise + "\n" + "Farbe: " + this.farbe + "\n" + "Gro�e: " + this.gro�e + "\n"
				+ "Produkt Details: " + produktDetails + "\n" + "Artkel-Nr: " + artikelNr + "\n" + "Material: "
				+ material + "\n" + "Pflege: " + pflege + "\n";
	}

	/**
	 * Getter Methode
	 * 
	 * @return image:String[]
	 */
	public String[] getImage() {
		return image;
	}

	/**
	 * Setter Methode
	 * 
	 * @param image: String[]
	 */
	public void setImage(String[] image) {
		this.image = image;
	}

	/**
	 * Getter Methode
	 * 
	 * @return id_produkt:Long
	 */
	public Long getId_produkt() {
		return id_produkt;
	}

	/**
	 * Setter Methode
	 * 
	 * @param farbe: String
	 */
	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}

	/**
	 * Setter Methode
	 * 
	 * @param gro�e : int
	 */
	public void setGro�e(int gro�e) {
		this.gro�e = gro�e;
	}

	/**
	 * Getter Methode
	 * 
	 * @return id_pullover:Long
	 */
	public Long getId_pullover() {
		return id_pullover;
	}

	/**
	 * Getter Mthode
	 * 
	 * @return farbe:String
	 */
	public String getFarbe() {
		return farbe;
	}

	/**
	 * Getter Methode
	 * 
	 * @return gro�e:int
	 */
	public int getGro�e() {
		return gro�e;
	}

	/**
	 * Getter Methode
	 * 
	 * @return mange
	 */
	public int getMange() {
		return mange;
	}

	/**
	 * Setter Methode
	 * 
	 * @param mange:int
	 */
	public void setMange(int mange) {
		this.mange = mange;
	}

	@Override
	public String toString() {
		return "Pullover [id_pullover=" + id_pullover + ", id_produkt=" + id_produkt + ", farbe=" + farbe + ", gro�e="
				+ gro�e + ", mange=" + mange + ", image=" + Arrays.toString(image) + ", preise=" + preise
				+ ", produktType=" + produktType + "]";
	}

}
