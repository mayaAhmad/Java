package de.bekleidungsgeschaeft.produkte;

import java.util.Arrays;

/**
 * Kalsse Jacke ist ein type von Produkt Objeckt Vererbung von Produkt object
 * 
 * @author maya
 *
 */

public class Jacke extends Produkt implements ProduktInfo {

	protected Long id_jacke;
	protected Long id_produkt;
	private String farbe;
	private int gro�e;
	private int mange;
	private String[] image = new String[4];

	/**
	 * default Constructors
	 */

	public Jacke() {

	}

	/**
	 * 
	 * @param id_produkt ist Long type , das parmeter k�nnten wir mit id_produkt in
	 *                   produkt Klasse verbinden ist ein foren Key
	 * @param farbe      ist String type ,jeader produkt hat farbe
	 * @param gro�e      ist int type, weleches gro�e hat dieses Jacke
	 * @param mange      ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image      ist ein Array String type ,es wird alle images von Jacke in
	 *                   array gespeischt
	 */
	public Jacke(Long id_produkt, String farbe, int gro�e, int mange, String[] image) {
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		produktType = "Jacke";
	}

	/**
	 * 
	 * @param id_jackeist Long Type, jeades Jacke hat einzig nummer und das ist
	 *                    primary key in DataBase
	 * @param id_produkt  ist Long type , das parmeter k�nnten wir mit id_produkt in
	 *                    produkt Klasse verbinden ist ein foren Key
	 * @param farbe       ist String type ,jeader produkt hat farbe
	 * @param gro�e       ist int type, weleches gro�e hat dieses Jacke
	 * @param mange       ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image       ist ein Array String type ,es wird alle images von Jacke
	 *                    in array gespeischt
	 */
	public Jacke(Long id_jacke, Long id_produkt, String farbe, int gro�e, int mange, String[] image) {
		this.id_jacke = id_jacke;
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		produktType = "Jacke";
	}

	/**
	 * 
	 * @param id_jackeist Long Type, jeades Jacke hat einzig nummer und das ist
	 *                    primary key in DataBase
	 * @param id_produkt  ist Long type , das parmeter k�nnten wir mit id_produkt in
	 *                    produkt Klasse verbinden ist ein foren Key
	 * @param farbe       ist String type ,jeader produkt hat farbe
	 * @param gro�e       ist int type, weleches gro�e hat dieses Jacke
	 * @param mange       ist ein int , wie wiele St�ck gibt es in der lage
	 * @param image       ist ein Array String type ,es wird alle images von Jacke
	 *                    in array gespeischt
	 * @param produktType ist String type , es wird hier Jacke gespiecht
	 */
	public Jacke(Long id_jacke, Long id_produkt, String farbe, int gro�e, int mange, String[] image, double preise,
			String produktType) {
		this.id_jacke = id_jacke;
		this.id_produkt = id_produkt;
		this.farbe = farbe;
		this.gro�e = gro�e;
		this.mange = mange;
		this.image = image;
		this.preise = preise;
		this.produktType = produktType;
	}

	/**
	 * diese Konstruktor halfen uns in dataBase zu verbenden
	 * 
	 * @param id_jacke ...
	 * @param mange....
	 */
	public Jacke(Long id_jacke, int mange) {
		this.id_jacke = id_jacke;
		this.mange = mange;
	}

	/**
	 * ein Mthode ,die einige Data in objeck griefen
	 */
	@Override
	public String getProduktInfo() {

		return "Preis " + preise + "\n" + "Farbe: " + this.farbe + "\n" + "Gro�e: " + this.gro�e + "\n"
				+ "Produkt Details: " + produktDetails + "\n" + "Artkel-Nr: " + artikelNr + "\n" + "Material: "
				+ material + "\n" + "Pflege: " + pflege + "\n";
	}

	/**
	 * Getter Methode
	 * 
	 * @return image:String Array
	 */
	public String[] getImage() {
		return image;
	}

	/**
	 * Setter Methode
	 * 
	 * @param image:String[]
	 */
	public void setImage(String[] image) {
		this.image = image;
	}

	/**
	 * Getter Methode
	 * 
	 * @return id_jacke:Long
	 */
	public Long getId_jacke() {
		return id_jacke;
	}

	/**
	 * Getter Methode
	 * 
	 * @return id_produkt:Long
	 */
	public Long getId_produkt() {
		return id_produkt;
	}

	/**
	 * Setter Methode
	 * 
	 * @param farbe:String
	 */
	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}

	/**
	 * Getter Methode
	 * 
	 * @return farbe:Sting
	 */
	public String getFarbe() {
		return farbe;
	}

	/**
	 * Getter Methode
	 * 
	 * @return gro�e :int
	 */
	public int getGro�e() {
		return gro�e;
	}

	/**
	 * Getter Methode
	 * 
	 * @return mange:int
	 */
	public int getMange() {
		return mange;
	}

	/**
	 * Setter Methode
	 * 
	 * @param mange:int
	 */
	public void setMange(int mange) {
		this.mange = mange;
	}

	@Override
	public String toString() {
		return "Jacke [id_jacke=" + id_jacke + ", id_produkt=" + id_produkt + ", farbe=" + farbe + ", gro�e=" + gro�e
				+ ", mange=" + mange + ", image=" + Arrays.toString(image) + ", preise=" + preise + ", produktType="
				+ produktType + "]";
	}

}
