package de.bekleidungsgeschaeft.middel;

import java.util.List;

import de.bekleidungsgeschaeft.backend.ProduktDAO;
import de.bekleidungsgeschaeft.produkte.Blazer;
import de.bekleidungsgeschaeft.produkte.Produkt;


public class ProduktService {
	private List<Produkt> alleProdukt;
	private ProduktDAO datenquelle;
	private Produkt produktByartikelNr;
//	private String artikelNr;
	
	public ProduktService(ProduktDAO quelle) {
		datenquelle = quelle;
		alleProdukt = datenquelle.getAllprodukt();
	//	produktByartikelNr=datenquelle.getPorduktById(artikelNr);
	}
	
	public Produkt getProduktByartikelNr(ProduktDAO quelle,String artikelNr) {
		datenquelle = quelle;
		produktByartikelNr=datenquelle.getPorduktByArtikelNr(artikelNr);
		return produktByartikelNr;
	}
	
	public Produkt getProduktById(Long id) {
		produktByartikelNr=datenquelle.getPorduktById(id);
		return produktByartikelNr;
	}
	
	public void insertProudukt(Produkt produkt) {
		datenquelle.addprodukt(produkt);
		
	}

	public List<Produkt> getAlleProdukt(){
		
		return alleProdukt;
	}
	public Produkt getAllemange(Long id ,String farbe, int gro�e) {
		return datenquelle.getAllMange(id, farbe, gro�e);
	}
	 public void updateMange(long id,String aendern) {
		 datenquelle.updateProdukt(id,aendern);
	 }


}
