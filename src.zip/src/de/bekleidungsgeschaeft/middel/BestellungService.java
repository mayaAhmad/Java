package de.bekleidungsgeschaeft.middel;

import java.util.List;

import de.bekleidungsgeschaeft.BestellungBackend.BestellungDAO;
import de.bekleidungsgeschaeft.backend.ProduktDAO;
import de.bekleidungsgeschaeft.besttellung.Bestellung;


public class BestellungService {
	private List<Bestellung> alleBestellung;
	private BestellungDAO datenquelle;
	
	
	public BestellungService(BestellungDAO quelle) {
		datenquelle = quelle;
		
	}
//	public List<Bestellung> getAlleBestellung() {
//		return alleBestellung;
//	}
	public List<Bestellung> getAllBestellung(int kassenBon){
		alleBestellung=datenquelle.getAllBestellung( kassenBon);
		return alleBestellung;
	}
	
	public void insertBestellung(Bestellung bestellung) {
		datenquelle.addBestellung(bestellung);
	}
	
	public List<Bestellung> getAllBestellungByIdKassenBon(int idKassenBon){
		List<Bestellung> bestellungs=datenquelle.getBestellungById(idKassenBon);
		return bestellungs;
	}
	public int getMaxIdKassenBon() {
		int kassen=datenquelle.getMaxIdKassenBon();
		return kassen;
	}

}
