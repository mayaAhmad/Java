package test;

import de.bekleidungsgeschaeft.fronted.HauptfensterAPI;

public class Testfenste {

	public static void main(String[] args) {
		new HauptfensterAPI().setVisible(true);
	}

}
