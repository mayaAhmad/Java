package xampel;

public class Ampel {
//https://en.wikipedia.org/wiki/ANSI_escape_code
//https://www.google.com/search?client=firefox-b-d&q=argouml
	public enum Phase{
		ROT(2,"\u001B[31m"), ROTGELB(1, "\u001B[33m"), GRUEN(3,"\u001B[32m"), GELB(1,"\u001B[93m");
		private int dauer;
		private String anzeigefarbe; 
	
		private Phase(int dauer,String anzeigefarbe) {
			this.dauer = dauer;
			this.anzeigefarbe = anzeigefarbe;
			//System.out.print("\u001B[31m");
		}
		/**
		 * @return the dauer
		 */
		public int getDauer() {
			return dauer;
		}
		/**
		 * @return the anzeigefarbe
		 */
		public String getAnzeigefarbe() {
			return anzeigefarbe;
		}
		
		
	}
	private Phase zustand;
	
	public Ampel() {
		zustand =Phase.ROT;
	}
	
	public void schalten() {
		
		try {
			Thread.sleep(zustand.getDauer()*1000);
		} catch (InterruptedException e) {
			
		}
		int phase = zustand.ordinal();
		zustand = Phase.values()[(phase+1)% Phase.values().length];
		//0 + 1 % 4 = 1
		//1 + 1 % 4 = 2
		//System.out.print(zustand.anzeigefarbe);
	}

	@Override
	public String toString() {
		return zustand.getAnzeigefarbe()+ "Ampel [zustand=" + zustand + "]";
	}
	
}
