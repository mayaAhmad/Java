package xampel;

public class Kreuzung {

	public static void main(String[] args) {
		Ampel ampel = new Ampel();
		while (true) {
			System.out.println(ampel);
			ampel.schalten();
			
		}

	}

}
